import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import MosqueSubmissionForm from "@/components/MosqueSubmissionForm";

const SubmitMosque = () => {
  return (
    <main className="min-h-screen bg-background pt-16">
      {/* Header Section */}
      <section className="bg-gradient-to-br from-secondary/30 to-background py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Link to="/mosques">
              <Button variant="ghost" className="mb-4 hover:bg-islamic-green/10">
                <ArrowLeft className="mr-2 w-4 h-4" />
                Back to Mosques
              </Button>
            </Link>
            
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                Submit a Mosque
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Help us build the most comprehensive directory of Islamic centers across the Midwest. 
                Your submission will be reviewed and added to our community directory.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Form Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <MosqueSubmissionForm />
        </div>
      </section>

      {/* Guidelines Section */}
      <section className="py-12 bg-secondary/20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold text-foreground mb-6">Submission Guidelines</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
              <div className="space-y-2">
                <h3 className="font-semibold text-islamic-green">Required Information</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Mosque or Islamic center name</li>
                  <li>• Complete street address</li>
                  <li>• City and state</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-islamic-green">Review Process</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Submissions are reviewed within 3-5 business days</li>
                  <li>• We may contact you for additional information</li>
                  <li>• Approved listings appear in our directory</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-islamic-green">Helpful Tips</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Provide accurate prayer times</li>
                  <li>• Include special programs and services</li>
                  <li>• Add contact information when possible</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-islamic-green">Updates</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Contact us to update existing listings</li>
                  <li>• Prayer times are updated seasonally</li>
                  <li>• Community input helps keep info current</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default SubmitMosque;