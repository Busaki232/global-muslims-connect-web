import ChatRoom from "@/components/ChatRoom";

const Chat = () => {
  return <ChatRoom />;
};

export default Chat;