import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { ConversationsList } from './ConversationsList';
import { PrivateChatWindow } from './PrivateChatWindow';
import { UserDirectory } from './UserDirectory';
import { Button } from './ui/button';
import { MessageCircle, Users, Plus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useUserGroups } from '@/hooks/useUserGroups';
import GroupsList from './GroupsList';
import GroupChatWindow from './GroupChatWindow';
import CreateGroupDialog from './CreateGroupDialog';
import GroupSettingsDialog from './GroupSettingsDialog';

interface Conversation {
  id: string;
  otherUserId: string;
  otherUserName: string;
  lastMessage?: string;
  lastMessageAt?: string;
  unreadCount: number;
}

const PrivateMessaging = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [showUserDirectory, setShowUserDirectory] = useState(false);
  const [activeTab, setActiveTab] = useState<'direct' | 'groups'>('direct');
  
  // Group states
  const { groups, loading: groupsLoading } = useUserGroups();
  const [selectedGroup, setSelectedGroup] = useState<any>(null);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [showGroupSettings, setShowGroupSettings] = useState(false);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Sign in to access private messaging</h2>
          <p className="text-muted-foreground">Connect with other community members privately</p>
        </div>
      </div>
    );
  }

  const handleSelectUser = (userId: string, userName: string) => {
    // Create or find conversation with this user
    const conversationId = [user.id, userId].sort().join('-');
    
    let conversation = conversations.find(c => c.id === conversationId);
    
    if (!conversation) {
      conversation = {
        id: conversationId,
        otherUserId: userId,
        otherUserName: userName,
        unreadCount: 0
      };
      setConversations(prev => [conversation!, ...prev]);
    }
    
    setSelectedConversation(conversation);
    setSelectedGroup(null);
    setShowUserDirectory(false);
  };

  const handleGroupCreated = (groupId: string) => {
    const newGroup = groups.find(g => g.id === groupId);
    if (newGroup) {
      setSelectedGroup(newGroup);
      setSelectedConversation(null);
      setActiveTab('groups');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="h-screen flex flex-col">
        {/* Header */}
        <div className="border-b bg-card">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold">Messages</h1>
              <div className="flex gap-2">
                <Button 
                  onClick={() => setShowUserDirectory(true)}
                  variant="outline"
                  className="gap-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  New Chat
                </Button>
                <Button 
                  onClick={() => setShowCreateGroup(true)}
                  className="gap-2"
                >
                  <Plus className="h-4 w-4" />
                  New Group
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar */}
          <div className="w-80 border-r bg-card flex flex-col">
            <Tabs value={activeTab} onValueChange={(v: any) => setActiveTab(v)} className="flex-1 flex flex-col">
              <div className="p-4 border-b">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="direct">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Direct
                  </TabsTrigger>
                  <TabsTrigger value="groups">
                    <Users className="h-4 w-4 mr-2" />
                    Groups
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="direct" className="flex-1 flex flex-col m-0">
                <ConversationsList
                  conversations={conversations}
                  selectedConversation={selectedConversation}
                  onSelectConversation={(conv) => {
                    setSelectedConversation(conv);
                    setSelectedGroup(null);
                  }}
                  onUpdateConversations={setConversations}
                />
              </TabsContent>

              <TabsContent value="groups" className="flex-1 flex flex-col m-0">
                <GroupsList
                  groups={groups}
                  selectedGroup={selectedGroup}
                  onSelectGroup={(group) => {
                    setSelectedGroup(group);
                    setSelectedConversation(null);
                  }}
                />
              </TabsContent>
            </Tabs>
          </div>

          {/* Chat Window */}
          <div className="flex-1 flex flex-col">
            {selectedConversation ? (
              <PrivateChatWindow
                conversation={selectedConversation}
                onUpdateConversation={(updated) => {
                  setConversations(prev =>
                    prev.map(c => c.id === updated.id ? updated : c)
                  );
                }}
              />
            ) : selectedGroup ? (
              <GroupChatWindow
                group={selectedGroup}
                onOpenSettings={() => setShowGroupSettings(true)}
              />
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No conversation selected</h3>
                  <p className="text-muted-foreground mb-4">
                    Choose a conversation or group, or start a new one
                  </p>
                  <div className="flex gap-2 justify-center">
                    <Button onClick={() => setShowUserDirectory(true)} variant="outline">
                      Start New Chat
                    </Button>
                    <Button onClick={() => setShowCreateGroup(true)}>
                      Create Group
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* User Directory Dialog */}
      <Dialog open={showUserDirectory} onOpenChange={setShowUserDirectory}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Start a New Conversation</DialogTitle>
          </DialogHeader>
          <UserDirectory
            onSelectUser={handleSelectUser}
            onClose={() => setShowUserDirectory(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Create Group Dialog */}
      <CreateGroupDialog
        open={showCreateGroup}
        onOpenChange={setShowCreateGroup}
        onGroupCreated={handleGroupCreated}
      />

      {/* Group Settings Dialog */}
      {selectedGroup && (
        <GroupSettingsDialog
          open={showGroupSettings}
          onOpenChange={setShowGroupSettings}
          group={selectedGroup}
        />
      )}
    </div>
  );
};

export default PrivateMessaging;