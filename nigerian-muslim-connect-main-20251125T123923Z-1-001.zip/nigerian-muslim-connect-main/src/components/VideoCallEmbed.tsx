import { useEffect, useRef, useState } from "react";
import DailyIframe from "@daily-co/daily-js";
import { X } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

interface VideoCallEmbedProps {
  roomUrl: string;
  onLeave: () => void;
  userName: string;
  isAudioOnly?: boolean;
}

export const VideoCallEmbed = ({ roomUrl, onLeave, userName, isAudioOnly = false }: VideoCallEmbedProps) => {
  const callFrameRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "joined" | "error">("idle");

  useEffect(() => {
    console.log("VideoCallEmbed mounted with roomUrl:", roomUrl);
    console.log("isAudioOnly:", isAudioOnly);

    // Check browser permissions
    if ("permissions" in navigator) {
      (navigator as any).permissions
        .query({ name: "camera" as PermissionName })
        .then((res: any) => console.log("[Permissions] camera:", res.state))
        .catch(() => {});
      (navigator as any).permissions
        .query({ name: "microphone" as PermissionName })
        .then((res: any) => console.log("[Permissions] microphone:", res.state))
        .catch(() => {});
    }

    if (!containerRef.current) {
      console.log("Container ref not ready");
      return;
    }

    if (callFrameRef.current) {
      console.log("Call frame already exists");
      return;
    }

    console.log("Creating Daily call frame...");
    setStatus("loading");

    // Create Daily call frame
    const callFrame = DailyIframe.createFrame(containerRef.current, {
      showLeaveButton: false,
      showFullscreenButton: true,
      iframeStyle: {
        width: "100%",
        height: "100%",
        border: "none",
        borderRadius: "0.5rem",
      },
    });

    callFrameRef.current = callFrame;

    // Add comprehensive event logging
    callFrame.on("loaded", () => {
      console.log("[Daily] iframe loaded");
    });

    callFrame.on("joined-meeting", (ev: any) => {
      console.log("[Daily] joined meeting", ev);
      setStatus("joined");
    });

    callFrame.on("camera-error", (ev: any) => {
      console.error("[Daily] camera error", ev);
      setStatus("error");
    });

    callFrame.on("access-state-updated", (ev: any) => {
      console.log("[Daily] access state updated", ev);
    });

    callFrame.on("participant-joined", (ev: any) => {
      console.log("[Daily] participant joined", ev);
    });

    callFrame.on("participant-updated", (ev: any) => {
      console.log("[Daily] participant updated", ev);
    });

    callFrame.on("participant-left", (ev: any) => {
      console.log("[Daily] participant left", ev);
    });

    callFrame.on("left-meeting", () => {
      console.log("[Daily] left meeting");
      onLeave();
    });

    callFrame.on("error", (error: any) => {
      console.error("[Daily] error", error);
      
      // Set more specific error status based on error type
      if (error?.errorMsg?.includes('not found') || error?.errorMsg?.includes('expired')) {
        console.error("[Daily] Room not found or expired");
      } else if (error?.errorMsg?.includes('access') || error?.errorMsg?.includes('denied')) {
        console.error("[Daily] Access denied - check permissions");
      }
      
      setStatus("error");
    });

    console.log("Joining call with URL:", roomUrl);

    // Join the call with proper configuration for audio/video
    const joinOptions: any = isAudioOnly
      ? {
          url: roomUrl,
          userName: userName,
          startVideoOff: true,
          startAudioOff: false,
          dailyConfig: {
            subscribeToTracks: { video: false, audio: true },
          },
        }
      : {
          url: roomUrl,
          userName: userName,
          startVideoOff: false,
          startAudioOff: false,
        };

    callFrame
      .join(joinOptions)
      .then(() => {
        console.log("[Daily] Join request successful");
        setStatus("joined");
      })
      .catch((error: any) => {
        console.error("[Daily] Error joining call:", error);
        setStatus("error");
      });

    // Safety timeout: if still loading after 20 seconds, show error
    const timeoutId = window.setTimeout(() => {
      setStatus((prev) => {
        if (prev === "loading") {
          console.warn("[Daily] Join timeout – still in loading state after 20s");
          return "error";
        }
        return prev;
      });
    }, 20000);

    // Cleanup on unmount
    return () => {
      console.log("Cleaning up call frame");
      window.clearTimeout(timeoutId);
      if (callFrameRef.current) {
        callFrameRef.current.destroy();
        callFrameRef.current = null;
      }
    };
  }, [roomUrl, userName, isAudioOnly, onLeave]);

  const handleLeave = () => {
    if (callFrameRef.current) {
      callFrameRef.current.leave();
    }
    onLeave();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
      <div className="w-full h-full max-w-7xl mx-auto flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-gray-900 text-white">
          <h2 className="text-lg font-semibold">{isAudioOnly ? "Voice Call" : "Video Call"}</h2>
          <Button variant="ghost" size="icon" onClick={handleLeave} className="text-white hover:bg-gray-800">
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Call container - Critical: Must have explicit height */}
        <div className="relative flex-1 bg-gray-900" ref={containerRef} style={{ minHeight: "600px" }}>
          {/* Connection status overlay */}
          {status !== "joined" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-black/50 z-10">
              {status === "loading" && (
                <div className="flex flex-col items-center gap-2">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
                  <p className="text-lg">Connecting to call…</p>
                </div>
              )}
              {status === "error" && (
                <div className="flex flex-col items-center gap-2 max-w-md text-center px-4">
                  <p className="text-xl font-semibold">Connection Failed</p>
                  <p className="text-sm text-gray-300">
                    Unable to connect to the call. Please check your camera/microphone permissions and internet connection, then try again.
                  </p>
                  <p className="text-xs text-gray-400 mt-2">
                    If the problem persists, the call room may have expired. Please start a new call.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-900 flex justify-center">
          <Button variant="destructive" onClick={handleLeave} size="lg">
            Leave Call
          </Button>
        </div>
      </div>
    </div>
  );
};
