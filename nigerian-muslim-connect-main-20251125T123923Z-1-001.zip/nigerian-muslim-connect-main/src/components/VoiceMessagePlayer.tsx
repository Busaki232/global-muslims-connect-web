import { useState, useEffect } from 'react';
import { Play, Pause } from 'lucide-react';
import { useAudioPlayer } from '@/hooks/useAudioPlayer';
import { AudioWaveform } from './AudioWaveform';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { logger } from '@/lib/logger';

interface VoiceMessagePlayerProps {
  audioUrl: string;
  duration: number;
  className?: string;
}

export const VoiceMessagePlayer = ({ 
  audioUrl, 
  duration,
  className 
}: VoiceMessagePlayerProps) => {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [urlError, setUrlError] = useState<string | null>(null);

  // Generate signed URL for private storage access with retry logic
  useEffect(() => {
    const generateSignedUrlWithRetry = async (filePath: string, retries = 3): Promise<string> => {
      for (let i = 0; i < retries; i++) {
        try {
          const { data, error } = await supabase.storage
            .from('message-attachments')
            .createSignedUrl(filePath, 3600);
            
          if (!error && data?.signedUrl) {
            return data.signedUrl;
          }
          
          logger.warn(`[VoicePlayer] Attempt ${i + 1} failed:`, error);
          
          if (i < retries - 1) {
            await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
          }
        } catch (err) {
          logger.error(`[VoicePlayer] Exception on attempt ${i + 1}:`, err);
          if (i === retries - 1) throw err;
        }
      }
      throw new Error('Failed to generate signed URL after retries');
    };

    const generateSignedUrl = async () => {
      let filePath = audioUrl;
      
      logger.info('[VoicePlayer] Processing audio URL:', audioUrl);
      
      // Handle legacy full URLs - extract the relative path
      if (audioUrl.startsWith('http')) {
        const match = audioUrl.match(/message-attachments\/(.+)$/);
        if (match) {
          filePath = match[1];
          logger.info('[VoicePlayer] Extracted path from legacy URL:', filePath);
        } else {
          logger.error('[VoicePlayer] Could not extract path from URL:', audioUrl);
          setUrlError('Invalid audio URL format');
          return;
        }
      }
      
      try {
        // Verify file exists before generating signed URL
        const pathParts = filePath.split('/');
        if (pathParts.length >= 2) {
          const { data: fileData, error: fileError } = await supabase.storage
            .from('message-attachments')
            .list(pathParts[0]);

          if (fileError || !fileData || fileData.length === 0) {
            logger.error('[VoicePlayer] Directory not accessible', fileError);
            setUrlError('Audio file not found');
            return;
          }
          
          const fileExists = fileData.some(file => file.name === pathParts[1]);
          if (!fileExists) {
            logger.error('[VoicePlayer] File not found:', pathParts[1]);
            setUrlError('Audio file not found');
            return;
          }
          
          logger.info('[VoicePlayer] File exists, generating signed URL');
        }
        
        // Generate signed URL with retry logic
        const signedUrl = await generateSignedUrlWithRetry(filePath);
        logger.info('[VoicePlayer] Signed URL generated successfully');
        setSignedUrl(signedUrl);
      } catch (err) {
        logger.error('[VoicePlayer] Error generating signed URL:', err);
        setUrlError('Failed to load audio');
      }
    };

    generateSignedUrl();
  }, [audioUrl]);

  const { isPlaying, currentTime, duration: audioDuration, togglePlayPause } = useAudioPlayer(signedUrl || '');

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = audioDuration > 0 ? currentTime / audioDuration : 0;
  const displayDuration = audioDuration > 0 ? audioDuration : duration;

  // Show error or loading state
  if (urlError) {
    return (
      <div className={cn("flex items-center gap-2 p-2 rounded-lg bg-muted/50 min-w-[250px]", className)}>
        <span className="text-xs text-destructive">{urlError}</span>
      </div>
    );
  }

  if (!signedUrl) {
    return (
      <div className={cn("flex items-center gap-2 p-2 rounded-lg bg-muted/50 min-w-[250px]", className)}>
        <span className="text-xs text-muted-foreground">Loading audio...</span>
      </div>
    );
  }

  return (
    <div className={cn("flex items-center gap-2 p-2 rounded-lg bg-muted/50 min-w-[250px]", className)}>
      <button
        onClick={togglePlayPause}
        className="flex-shrink-0 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 transition-opacity"
        disabled={!signedUrl}
      >
        {isPlaying ? (
          <Pause className="w-5 h-5" />
        ) : (
          <Play className="w-5 h-5 ml-0.5" />
        )}
      </button>

      <AudioWaveform 
        duration={displayDuration} 
        progress={progress}
        isPlaying={isPlaying}
        className="flex-1"
      />

      <span className="text-xs font-mono text-muted-foreground flex-shrink-0">
        {formatTime(isPlaying ? currentTime : displayDuration)}
      </span>
    </div>
  );
};
