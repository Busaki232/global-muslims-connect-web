import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Star } from 'lucide-react';
import { useIslamicCalendar, HIJRI_MONTHS } from '@/hooks/useIslamicCalendar';
import { format } from 'date-fns';

export const IslamicCalendar = () => {
  const { currentDate, hijriDate, holidays, upcomingHolidays, loading, getHolidayForDate } = useIslamicCalendar();
  const [selectedMonth, setSelectedMonth] = useState(hijriDate?.month || 1);
  const [selectedYear, setSelectedYear] = useState(hijriDate?.year || 1446);

  if (loading || !hijriDate) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const handlePreviousMonth = () => {
    if (selectedMonth === 1) {
      setSelectedMonth(12);
      setSelectedYear(selectedYear - 1);
    } else {
      setSelectedMonth(selectedMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 12) {
      setSelectedMonth(1);
      setSelectedYear(selectedYear + 1);
    } else {
      setSelectedMonth(selectedMonth + 1);
    }
  };

  const handleToday = () => {
    setSelectedMonth(hijriDate.month);
    setSelectedYear(hijriDate.year);
  };

  // Generate calendar days (simplified - 30 days per month)
  const calendarDays = Array.from({ length: 30 }, (_, i) => i + 1);

  return (
    <div className="space-y-6">
      {/* Current Date Display */}
      <Card className="p-6 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <CalendarIcon className="h-5 w-5" />
            <span>{format(currentDate, 'EEEE, MMMM dd, yyyy')}</span>
          </div>
          <div className="text-3xl font-bold text-primary" dir="rtl">
            {hijriDate.day} {HIJRI_MONTHS[hijriDate.month - 1].arabic} {hijriDate.year}
          </div>
          <div className="text-xl text-foreground">
            {HIJRI_MONTHS[hijriDate.month - 1].english} {hijriDate.day}, {hijriDate.year} AH
          </div>
        </div>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Calendar View */}
        <Card className="md:col-span-2 p-6">
          {/* Month Navigation */}
          <div className="flex items-center justify-between mb-6">
            <Button onClick={handlePreviousMonth} variant="outline" size="sm">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <div className="text-center">
              <div className="text-lg font-bold" dir="rtl">
                {HIJRI_MONTHS[selectedMonth - 1].arabic}
              </div>
              <div className="text-sm text-muted-foreground">
                {HIJRI_MONTHS[selectedMonth - 1].english} {selectedYear} AH
              </div>
            </div>

            <Button onClick={handleNextMonth} variant="outline" size="sm">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex justify-center mb-4">
            <Button onClick={handleToday} variant="outline" size="sm">
              Today
            </Button>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Day headers */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
                {day}
              </div>
            ))}

            {/* Calendar days */}
            {calendarDays.map((day) => {
              const holiday = getHolidayForDate(selectedMonth, day);
              const isToday = 
                selectedMonth === hijriDate.month && 
                day === hijriDate.day && 
                selectedYear === hijriDate.year;
              const isFriday = (day % 7) === 6; // Simplified Friday detection

              return (
                <button
                  key={day}
                  className={`
                    aspect-square p-2 rounded-lg text-sm font-medium
                    transition-all hover:bg-accent hover:scale-105
                    ${isToday ? 'bg-primary text-primary-foreground hover:bg-primary/90' : ''}
                    ${isFriday && !isToday ? 'bg-accent text-accent-foreground' : ''}
                    ${holiday ? 'ring-2 ring-primary ring-offset-2' : ''}
                  `}
                >
                  <div className="flex flex-col items-center gap-1">
                    <span>{day}</span>
                    {holiday && (
                      <Star className="h-3 w-3 fill-primary text-primary" />
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </Card>

        {/* Upcoming Holidays Sidebar */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Star className="h-5 w-5 text-primary" />
            Upcoming Events
          </h3>
          
          <div className="space-y-4">
            {upcomingHolidays.length > 0 ? (
              upcomingHolidays.map((holiday) => (
                <div key={holiday.id} className="space-y-2 pb-4 border-b last:border-b-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-medium text-sm">{holiday.name}</div>
                    {holiday.is_major_holiday && (
                      <Badge variant="default" className="text-xs">Major</Badge>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground" dir="rtl">
                    {holiday.name_arabic}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {HIJRI_MONTHS[holiday.hijri_month - 1].english} {holiday.hijri_day}
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {holiday.description}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                No upcoming holidays in the next 60 days
              </p>
            )}
          </div>

          {/* All Holidays Link */}
          <div className="mt-6 pt-4 border-t">
            <h4 className="font-medium text-sm mb-3">All Islamic Holidays</h4>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {holidays.map((holiday) => (
                <div key={holiday.id} className="text-xs flex items-center justify-between gap-2 py-1">
                  <span className="truncate">{holiday.name}</span>
                  <span className="text-muted-foreground whitespace-nowrap">
                    {holiday.hijri_month}/{holiday.hijri_day}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Holiday Details Section */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {holidays.filter(h => h.is_major_holiday).map((holiday) => (
          <Card key={holiday.id} className="p-4 hover:shadow-lg transition-shadow">
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <h4 className="font-semibold">{holiday.name}</h4>
                <Star className="h-4 w-4 text-primary fill-primary" />
              </div>
              <p className="text-sm text-muted-foreground" dir="rtl">
                {holiday.name_arabic}
              </p>
              <div className="text-xs text-muted-foreground">
                {HIJRI_MONTHS[holiday.hijri_month - 1].english} {holiday.hijri_day}
              </div>
              <p className="text-sm">{holiday.description}</p>
              <p className="text-xs text-muted-foreground italic">
                {holiday.significance}
              </p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
