import { Reciter } from "@/data/quranData";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { User } from "lucide-react";

interface ReciterSelectorProps {
  reciters: Reciter[];
  onSelect: (reciter: Reciter) => void;
  selectedReciter: Reciter | null;
}

const ReciterSelector = ({ reciters, onSelect, selectedReciter }: ReciterSelectorProps) => {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
        <User className="h-4 w-4" />
        Select Reciter
      </label>
      <Select
        value={selectedReciter?.id || ""}
        onValueChange={(value) => {
          const reciter = reciters.find((r) => r.id === value);
          if (reciter) onSelect(reciter);
        }}
      >
        <SelectTrigger className="w-full bg-background/50 border-islamic-gold/20">
          <SelectValue placeholder="Choose a reciter" />
        </SelectTrigger>
        <SelectContent>
          {reciters.map((reciter) => (
            <SelectItem key={reciter.id} value={reciter.id}>
              <div className="flex flex-col items-start">
                <span className="font-medium">{reciter.name}</span>
                <span className="text-xs text-muted-foreground">{reciter.style}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default ReciterSelector;
