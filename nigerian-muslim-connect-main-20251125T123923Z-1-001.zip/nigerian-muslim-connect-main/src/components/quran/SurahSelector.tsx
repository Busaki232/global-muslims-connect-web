import { useState } from "react";
import { Surah } from "@/data/quranData";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SurahSelectorProps {
  surahs: Surah[];
  onSelect: (surah: Surah) => void;
  selectedSurah: Surah | null;
}

const SurahSelector = ({ surahs, onSelect, selectedSurah }: SurahSelectorProps) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredSurahs = surahs.filter(
    (surah) =>
      surah.englishName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      surah.englishTranslation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      surah.number.toString().includes(searchTerm)
  );

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search surah by name or number..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 bg-background/50 border-islamic-gold/20 focus:border-islamic-gold"
        />
      </div>

      <Select
        value={selectedSurah?.number.toString() || ""}
        onValueChange={(value) => {
          const surah = surahs.find((s) => s.number === parseInt(value));
          if (surah) onSelect(surah);
        }}
      >
        <SelectTrigger className="w-full bg-background/50 border-islamic-gold/20">
          <SelectValue placeholder="Select a surah" />
        </SelectTrigger>
        <SelectContent className="max-h-[300px]">
          <ScrollArea className="h-[300px]">
            {filteredSurahs.map((surah) => (
              <SelectItem key={surah.number} value={surah.number.toString()}>
                <div className="flex items-center justify-between w-full gap-4">
                  <span className="font-medium">{surah.number}.</span>
                  <span className="text-lg" style={{ fontFamily: 'serif' }}>{surah.name}</span>
                  <div className="flex flex-col items-start">
                    <span className="font-medium">{surah.englishName}</span>
                    <span className="text-xs text-muted-foreground">
                      {surah.englishTranslation}
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {surah.ayahs} verses
                  </span>
                </div>
              </SelectItem>
            ))}
          </ScrollArea>
        </SelectContent>
      </Select>
    </div>
  );
};

export default SurahSelector;
