import { useEffect } from "react";
import { allSurahs, reciters, Reciter, Surah } from "@/data/quranData";
import SurahSelector from "./SurahSelector";
import ReciterSelector from "./ReciterSelector";
import PlaybackControls from "./PlaybackControls";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, BookOpen } from "lucide-react";

interface QuranPlayerProps {
  isPlaying: boolean;
  currentSurah: Surah | null;
  currentReciter: Reciter | null;
  progress: number;
  duration: number;
  volume: number;
  isLoading: boolean;
  error: string | null;
  userInteracted: boolean;
  loadSurah: (surah: Surah, reciter: Reciter) => Promise<void>;
  togglePlayPause: () => void;
  seek: (time: number) => void;
  changeVolume: (volume: number) => void;
  selectedReciter: Reciter;
  onReciterChange: (reciter: Reciter) => void;
}

const QuranPlayer = ({
  isPlaying,
  currentSurah,
  currentReciter,
  progress,
  duration,
  volume,
  isLoading,
  error,
  userInteracted,
  loadSurah,
  togglePlayPause,
  seek,
  changeVolume,
  selectedReciter,
  onReciterChange,
}: QuranPlayerProps) => {
  // Don't auto-load on mount - require user interaction for mobile compatibility

  const handleSurahSelect = (surah: typeof allSurahs[0]) => {
    loadSurah(surah, selectedReciter);
  };

  const handleReciterSelect = (reciter: Reciter) => {
    onReciterChange(reciter);
    if (currentSurah) {
      loadSurah(currentSurah, reciter);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto bg-card/50 backdrop-blur-sm border-islamic-accent/20 shadow-islamic">
      <CardHeader className="text-center border-b border-islamic-accent/10">
        <div className="flex items-center justify-center gap-2 mb-2">
          <BookOpen className="h-6 w-6 text-islamic-accent" />
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-islamic-primary to-islamic-accent bg-clip-text text-transparent">
            Quran Audio Player
          </CardTitle>
        </div>
        {currentSurah ? (
          <div className="space-y-1">
            <p className="text-3xl font-serif text-islamic-gold">{currentSurah.name}</p>
            <p className="text-lg font-semibold text-foreground">{currentSurah.englishName}</p>
            <p className="text-sm text-muted-foreground">{currentSurah.englishTranslation}</p>
            <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground mt-2">
              <span>{currentSurah.ayahs} verses</span>
              <span>•</span>
              <span>{currentSurah.revelation}</span>
            </div>
          </div>
        ) : (
          <div className="space-y-2 py-4">
            <p className="text-lg font-medium text-muted-foreground">Get Started</p>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Select a reciter and a Surah below to begin listening to the Holy Quran
            </p>
          </div>
        )}
      </CardHeader>
      
      <CardContent className="space-y-6 p-6">
        {/* Empty state instructions */}
        {!currentSurah && !error && (
          <div className="bg-muted/50 border border-islamic-gold/20 rounded-lg p-6 text-center space-y-3">
            <p className="text-sm font-medium text-foreground">
              🎧 How to Listen
            </p>
            <ol className="text-sm text-muted-foreground space-y-2 text-left max-w-md mx-auto">
              <li className="flex items-start gap-2">
                <span className="font-semibold text-islamic-gold">1.</span>
                <span>Select your preferred reciter below</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-islamic-gold">2.</span>
                <span>Choose a Surah from the dropdown or tap a Popular Surah card</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-islamic-gold">3.</span>
                <span>Wait for the audio to load, then press play</span>
              </li>
            </ol>
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <ReciterSelector
          reciters={reciters}
          onSelect={handleReciterSelect}
          selectedReciter={selectedReciter}
        />

        <SurahSelector
          surahs={allSurahs}
          onSelect={handleSurahSelect}
          selectedSurah={currentSurah}
        />

        <PlaybackControls
          isPlaying={isPlaying}
          isLoading={isLoading}
          progress={progress}
          duration={duration}
          volume={volume}
          onPlayPause={togglePlayPause}
          onSeek={seek}
          onVolumeChange={changeVolume}
        />

        {currentReciter && (
          <div className="text-center text-sm text-muted-foreground pt-4 border-t border-islamic-accent/10">
            Recited by <span className="font-medium text-foreground">{currentReciter.name}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default QuranPlayer;
