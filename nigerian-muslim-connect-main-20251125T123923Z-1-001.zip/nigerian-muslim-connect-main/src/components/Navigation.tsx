import { MessageCircle, Home, Users, MapPin, Menu, X, ShoppingBag, LogIn, LogOut, User, Building, Calendar, BarChart3, BookOpen, Shield, Store } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { HeroButton } from "@/components/ui/hero-button";
import { useAuth } from "@/hooks/useAuth";
import { useUserRoles } from "@/hooks/useUserRoles";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSelector } from "@/components/LanguageSelector";
import { useTranslation } from "react-i18next";
import tariqIslamLogo from "@/assets/tariq-islam-logo.jpeg";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { user, signOut, loading } = useAuth();
  const { isAdmin } = useUserRoles();
  const { t } = useTranslation(['navigation', 'common']);

  const navItems = [
    { name: t('navigation:home'), href: "/", icon: Home },
    ...(user ? [{ name: t('navigation:dashboard'), href: "/dashboard", icon: BarChart3 }] : []),
    ...(isAdmin ? [
      { name: t('navigation:admin'), href: "/admin", icon: Shield },
      { name: "Moderation", href: "/moderation", icon: Shield }
    ] : []),
    { name: t('navigation:quran'), href: "/#quran-section", icon: BookOpen },
    { name: "Chat Room", href: "/chat", icon: MessageCircle },
    { name: "Messages", href: "/messages", icon: MessageCircle },
    { name: t('navigation:mosques'), href: "/mosques", icon: Building },
    { name: t('navigation:events'), href: "/events", icon: Calendar },
    { name: "Marketplace", href: "/marketplace", icon: ShoppingBag },
    ...(user ? [{ name: "My Ads", href: "/my-ads", icon: Store }] : []),
    { name: "Community", href: "/#community", icon: Users },
    { name: "Locations", href: "/#midwest", icon: MapPin },
  ];

  const isActive = (href: string) => {
    if (href === "/") return location.pathname === "/";
    if (href.startsWith("#")) return false; // Handle scroll links differently
    return location.pathname === href;
  };

  return (
    <nav className="bg-white/95 backdrop-blur-sm border-b border-border/50 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-xl font-bold text-foreground">
              Tariq Islam
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6 flex-1 justify-center">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={(e) => {
                    if (item.href.includes('#')) {
                      e.preventDefault();
                      const targetId = item.href.split('#')[1];
                      const targetElement = document.getElementById(targetId);
                      if (targetElement) {
                        targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                      if (location.pathname !== '/') {
                        window.location.href = item.href;
                      }
                    }
                  }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
                    isActive(item.href)
                      ? "bg-gradient-primary text-white shadow-islamic"
                      : "text-muted-foreground hover:text-islamic-green hover:bg-secondary/50"
                  }`}
                >
                  <IconComponent size={18} />
                  <span className="font-medium">{item.name}</span>
                </Link>
              );
            })}
            
            {/* Right Corner: Language Selector, Theme Toggle & Auth Buttons */}
            <div className="flex items-center gap-4 ml-auto">
              <LanguageSelector />
              <ThemeToggle />
              
              {user ? (
                <div className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground hidden lg:flex items-center gap-2">
                    <User size={16} />
                    Welcome back!
                  </span>
                  <Button 
                    onClick={signOut} 
                    variant="outline" 
                    size="sm" 
                    disabled={loading}
                    className="flex items-center gap-2"
                  >
                    <LogOut size={16} />
                    Sign Out
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Link to="/auth">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      <LogIn size={16} />
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/auth">
                    <Button 
                      variant="default"
                      size="sm"
                      className="bg-gradient-primary hover:opacity-90 shadow-islamic flex items-center gap-2"
                    >
                      <User size={16} />
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-3 min-h-[44px] min-w-[44px] rounded-lg hover:bg-secondary/50 active:bg-secondary/70 transition-all touch-manipulation active:scale-95"
            aria-label={isOpen ? "Close menu" : "Open menu"}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden border-t border-border/50 py-4">
            <div className="flex flex-col gap-2">
              {navItems.map((item) => {
                const IconComponent = item.icon;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    onClick={(e) => {
                      if (item.href.includes('#')) {
                        e.preventDefault();
                        const targetId = item.href.split('#')[1];
                        const targetElement = document.getElementById(targetId);
                        if (targetElement) {
                          targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                        if (location.pathname !== '/') {
                          window.location.href = item.href;
                        }
                      }
                      setIsOpen(false);
                    }}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                      isActive(item.href)
                        ? "bg-gradient-primary text-white shadow-islamic"
                        : "text-muted-foreground hover:text-islamic-green hover:bg-secondary/50"
                    }`}
                  >
                    <IconComponent size={20} />
                    <span className="font-medium">{item.name}</span>
                  </Link>
                );
              })}
              
              {/* Mobile Language Selector, Theme Toggle & Auth Section */}
              <div className="border-t border-border/50 pt-4 mt-2">
                <div className="px-4 pb-3">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-foreground">Language</span>
                    <LanguageSelector />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">Theme</span>
                    <ThemeToggle />
                  </div>
                </div>
                {user ? (
                  <div className="space-y-3">
                    <div className="px-4 py-2 text-sm text-muted-foreground flex items-center gap-2">
                      <User size={16} />
                      Welcome back!
                    </div>
                    <Button
                      onClick={() => {
                        signOut();
                        setIsOpen(false);
                      }}
                      variant="outline"
                      size="sm"
                      disabled={loading}
                      className="w-full mx-4 flex items-center gap-2"
                    >
                      <LogOut size={16} />
                      {t('navigation:signOut')}
                    </Button>
                  </div>
                ) : (
                  <Link to="/auth" onClick={() => setIsOpen(false)}>
                    <Button 
                      variant="default"
                      size="sm"
                      className="w-full mx-4 bg-gradient-primary hover:opacity-90 shadow-islamic flex items-center gap-2"
                    >
                      <LogIn size={16} />
                      {t('navigation:signIn')}
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;