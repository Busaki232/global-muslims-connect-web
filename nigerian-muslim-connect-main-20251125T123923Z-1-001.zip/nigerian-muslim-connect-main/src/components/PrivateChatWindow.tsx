import { useState, useEffect, useRef, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useTypingIndicator } from "@/hooks/useTypingIndicator";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { MessageStatus } from "./MessageStatus";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Send, MoreVertical, Trash2, Smile, Mic } from "lucide-react";
import { VoiceMessageRecorder } from "./VoiceMessageRecorder";
import { VoiceMessagePlayer } from "./VoiceMessagePlayer";
import { ImageUpload } from "./ImageUpload";
import { MessageAttachment } from "./MessageAttachment";
import { MessageReactions } from "./MessageReactions";
import { VideoCallButton } from "./VideoCallButton";
import { VideoCallEmbed } from "./VideoCallEmbed";
import { useActiveCall } from "@/hooks/useActiveCall";
import { uploadVoiceMessage, recordVoiceAttachment } from "@/utils/voiceMessageUpload";
import { logger } from "@/lib/logger";
import { format, formatDistanceToNow, isToday, isYesterday } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import EmojiPicker from "emoji-picker-react";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";

interface Conversation {
  id: string;
  otherUserId: string;
  otherUserName: string;
  lastMessage?: string;
  lastMessageAt?: string;
  unreadCount: number;
}

interface Message {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  created_at: string;
  is_deleted: boolean;
  read_by?: any;
  message_type?: string;
  metadata?: any;
  status?: "sending" | "sent" | "delivered" | "read";
  reactions?: Record<string, string[]>;
}

interface PrivateChatWindowProps {
  conversation: Conversation;
  onUpdateConversation: (conversation: Conversation) => void;
}

export const PrivateChatWindow = ({ conversation, onUpdateConversation }: PrivateChatWindowProps) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [messageToDelete, setMessageToDelete] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [messageAttachments, setMessageAttachments] = useState<Record<string, any[]>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const processedMessageIds = useRef(new Set<string>());
  const { activeCallRoom, callType, isInCall, endCall } = useActiveCall();

  const { typingUsers, startTyping, stopTyping } = useTypingIndicator(`private-${conversation.id}`);

  // Stabilize conversation dependency
  const conversationId = useMemo(() => conversation.id, [conversation.id]);

  // Authentication guard - early return if not authenticated
  if (!user) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Please sign in to send messages.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  useEffect(() => {
    if (!user || !conversation) return;

    loadMessages();
    loadAllAttachments();
    markMessagesAsRead();

    const channel = supabase
      .channel(`conversation-${conversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
        },
        (payload) => {
          const newMsg = payload.new as Message;
          // Only process messages from OTHER users (self-sent messages are handled optimistically)
          if (newMsg.sender_id === conversation.otherUserId && newMsg.recipient_id === user.id) {
            // Check if we've already processed this message
            if (processedMessageIds.current.has(newMsg.id)) {
              return;
            }

            processedMessageIds.current.add(newMsg.id);

            setMessages((prev) => {
              const exists = prev.some((msg) => msg.id === newMsg.id);
              if (exists) return prev;
              return [...prev, newMsg];
            });
            scrollToBottom();
            markMessagesAsRead();
          }
        },
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "messages",
        },
        (payload) => {
          const updatedMsg = payload.new as Message;
          if (
            (updatedMsg.sender_id === user.id && updatedMsg.recipient_id === conversation.otherUserId) ||
            (updatedMsg.sender_id === conversation.otherUserId && updatedMsg.recipient_id === user.id)
          ) {
            if (updatedMsg.is_deleted) {
              setMessages((prev) => prev.filter((msg) => msg.id !== updatedMsg.id));
            } else {
              setMessages((prev) => prev.map((msg) => (msg.id === updatedMsg.id ? updatedMsg : msg)));
            }
          }
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      // Clear processed IDs for this conversation
      processedMessageIds.current.clear();
    };
  }, [user, conversationId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Verify user session on component mount
  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session) {
        toast({
          title: "Authentication required",
          description: "Please log in to send messages.",
          variant: "destructive",
        });
      }
    };
    checkAuth();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadMessages = async () => {
    if (!user || !conversation) return;

    try {
      const { data, error } = await supabase
        .from("messages")
        .select(
          `
          id,
          sender_id,
          recipient_id,
          content,
          created_at,
          is_deleted,
          read_by,
          message_type,
          metadata,
          status,
          reactions
        `,
        )
        .or(
          `and(sender_id.eq.${user.id},recipient_id.eq.${conversation.otherUserId}),and(sender_id.eq.${conversation.otherUserId},recipient_id.eq.${user.id})`,
        )
        .eq("is_deleted", false)
        .order("created_at", { ascending: true });

      if (error) throw error;

      setMessages((data || []) as Message[]);
    } catch (error) {
      console.error("Error loading messages:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadAllAttachments = async () => {
    if (!messages.length) return;

    const messageIds = messages.map((m) => m.id);
    const { data, error } = await supabase.from("message_attachments").select("*").in("message_id", messageIds);

    if (error) {
      console.error("Error loading attachments:", error);
      return;
    }

    const attachmentsByMessage: Record<string, any[]> = {};
    data?.forEach((attachment) => {
      if (!attachmentsByMessage[attachment.message_id]) {
        attachmentsByMessage[attachment.message_id] = [];
      }
      attachmentsByMessage[attachment.message_id].push(attachment);
    });

    setMessageAttachments(attachmentsByMessage);
  };

  const markMessagesAsRead = async () => {
    if (!user || !conversation) return;

    try {
      await supabase.rpc("mark_messages_as_read", {
        _sender_id: conversation.otherUserId,
        _recipient_id: user.id,
      });
    } catch (error) {
      console.error("Error marking messages as read:", error);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newMessage.trim()) return;

    // Refresh session to ensure token is valid
    const {
      data: { session: freshSession },
      error: sessionError,
    } = await supabase.auth.refreshSession();

    if (sessionError || !freshSession) {
      toast({
        title: "Session error",
        description: "Please log in again.",
        variant: "destructive",
      });
      return;
    }

    if (!conversation) {
      toast({
        title: "Cannot send message",
        description: "Please ensure conversation is loaded.",
        variant: "destructive",
      });
      return;
    }

    const tempMessage: Message = {
      id: `temp-${Date.now()}`,
      sender_id: freshSession.user.id,
      recipient_id: conversation.otherUserId,
      content: newMessage.trim(),
      created_at: new Date().toISOString(),
      is_deleted: false,
      read_by: [],
      status: "sending",
    };

    setMessages((prev) => [...prev, tempMessage]);
    setNewMessage("");
    stopTyping();

    try {
      // Use fresh session user ID for sender_id
      const messageData = {
        sender_id: freshSession.user.id,
        recipient_id: conversation.otherUserId,
        content: tempMessage.content,
        message_type: "text",
      };

      const { data, error } = await supabase.from("messages").insert([messageData]).select().single();

      if (error) throw error;

      // Mark this message as processed
      processedMessageIds.current.add(data.id);

      // Replace temp with real message
      setMessages((prev) => prev.map((msg) => (msg.id === tempMessage.id ? (data as Message) : msg)));

      onUpdateConversation({
        ...conversation,
        lastMessage: messageData.content,
        lastMessageAt: data.created_at,
      });
    } catch (error: any) {
      console.error("=== Message Send Error Details ===");
      console.error("Error:", error);
      console.error("Error Code:", error?.code);
      console.error("Error Message:", error?.message);
      console.error("Error Details:", error?.details);
      console.error("Error Hint:", error?.hint);
      console.error("User ID from context:", user?.id);
      console.error("User ID from session:", freshSession?.user?.id);
      console.error("Recipient ID:", conversation.otherUserId);

      setMessages((prev) => prev.filter((msg) => msg.id !== tempMessage.id));

      // Check if it's an RLS error
      if (error?.message?.includes("row-level security")) {
        toast({
          title: "Authentication error",
          description: "Please refresh the page and try again.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Failed to send",
          description: "Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(e);
    }
  };

  const handleVoiceMessageSend = async (audioBlob: Blob, duration: number, mimeType: string) => {
    // Refresh session for voice messages too
    const {
      data: { session: freshSession },
      error: sessionError,
    } = await supabase.auth.refreshSession();

    if (sessionError || !freshSession) {
      toast({
        title: "Session error",
        description: "Please log in again.",
        variant: "destructive",
      });
      return;
    }

    if (!conversation) return;

    try {
      logger.info("[PrivateChat] Starting voice message send process");

      // Step 1: Create message record first to get real UUID using fresh session
      const { data: messageData, error: messageError } = await supabase
        .from("messages")
        .insert({
          sender_id: freshSession.user.id,
          recipient_id: conversation.otherUserId,
          content: "", // Will be updated with file path
          message_type: "voice",
          metadata: { duration, mimeType },
        })
        .select()
        .single();

      if (messageError) throw messageError;

      logger.info("[PrivateChat] Message created with ID:", messageData.id);

      // Step 2: Upload voice file using the real message UUID
      const filePath = await uploadVoiceMessage(audioBlob, messageData.id, user.id, mimeType);

      logger.info("[PrivateChat] File uploaded to:", filePath);

      // Step 3: Record attachment metadata
      await recordVoiceAttachment(messageData.id, filePath, mimeType, audioBlob.size, user.id);

      // Step 4: Update message content with file path
      const { error: updateError } = await supabase
        .from("messages")
        .update({ content: filePath })
        .eq("id", messageData.id);

      if (updateError) throw updateError;

      logger.info("[PrivateChat] Voice message send completed successfully");

      setIsRecordingVoice(false);
      toast({
        title: "Voice message sent",
        description: "Your voice message has been delivered.",
      });
    } catch (error: any) {
      logger.error("[PrivateChat] Error sending voice message", error);
      toast({
        title: "Failed to send",
        description: error.message || "Could not send voice message",
        variant: "destructive",
      });
    }
  };

  const handleDeleteMessage = async () => {
    if (!messageToDelete || !user) return;

    const messageToDeleteObj = messages.find((m) => m.id === messageToDelete);
    if (!messageToDeleteObj || messageToDeleteObj.sender_id !== user.id) {
      toast({
        title: "Permission denied",
        description: "You can only delete your own messages.",
        variant: "destructive",
      });
      return;
    }

    setDeleting(true);

    try {
      const { error } = await supabase.from("messages").update({ is_deleted: true }).eq("id", messageToDelete);

      if (error) throw error;

      setMessages((prev) => prev.filter((msg) => msg.id !== messageToDelete));

      toast({
        title: "Message deleted",
        description: "Your message has been removed",
      });
    } catch (error: any) {
      console.error("Error deleting message:", error);
      toast({
        title: "Error",
        description: error?.message || "Failed to delete message.",
        variant: "destructive",
      });
    } finally {
      setDeleting(false);
      setMessageToDelete(null);
    }
  };

  const getMessageStatus = (message: Message): "sending" | "sent" | "delivered" | "read" => {
    if (message.status) return message.status;
    if (message.read_by && Array.isArray(message.read_by) && message.read_by.length > 0) return "read";
    return "delivered";
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    if (isToday(date)) {
      return format(date, "h:mm a");
    } else if (isYesterday(date)) {
      return `Yesterday ${format(date, "h:mm a")}`;
    } else {
      return format(date, "MMM d, h:mm a");
    }
  };

  const getDateSeparator = (timestamp: string) => {
    const date = new Date(timestamp);
    if (isToday(date)) return "Today";
    if (isYesterday(date)) return "Yesterday";
    return format(date, "MMMM d, yyyy");
  };

  const shouldShowDateSeparator = (currentMsg: Message, previousMsg?: Message) => {
    if (!previousMsg) return true;
    const currentDate = new Date(currentMsg.created_at).toDateString();
    const previousDate = new Date(previousMsg.created_at).toDateString();
    return currentDate !== previousDate;
  };

  const onEmojiClick = (emojiData: any) => {
    setNewMessage((prev) => prev + emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);
    if (e.target.value.length > 0) {
      startTyping();
    } else {
      stopTyping();
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Active Call Overlay */}
      {activeCallRoom && (
        <VideoCallEmbed
          roomUrl="https://https://global-muslims-connec.daily.co/gmc-main-room"
          onLeave={endCall}
          userName={user?.user_metadata?.full_name || "User"}
          isAudioOnly={callType === "audio"}
        />
      )}

      {/* Header */}
      <div className="border-b p-4 bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarFallback>{conversation.otherUserName?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold">{conversation.otherUserName}</h3>
              {typingUsers.length > 0 && <p className="text-sm text-muted-foreground">typing...</p>}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <VideoCallButton
              conversationId={conversation.id}
              recipientName={conversation.otherUserName}
              variant="video"
            />
            <VideoCallButton
              conversationId={conversation.id}
              recipientName={conversation.otherUserName}
              variant="audio"
            />
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4" ref={messagesContainerRef}>
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-muted-foreground">Loading messages...</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-muted-foreground">No messages yet. Start the conversation!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message, index) => {
              const isOwnMessage = message.sender_id === user.id;
              const showDate = shouldShowDateSeparator(message, messages[index - 1]);

              return (
                <div key={message.id}>
                  {showDate && (
                    <div className="flex justify-center my-4">
                      <span className="px-3 py-1 text-xs bg-muted rounded-full">
                        {getDateSeparator(message.created_at)}
                      </span>
                    </div>
                  )}
                  <div className={`flex items-start gap-2 ${isOwnMessage ? "flex-row-reverse" : ""}`}>
                    <Avatar className="w-8 h-8">
                      <AvatarFallback>{isOwnMessage ? "You" : conversation.otherUserName?.[0] || "U"}</AvatarFallback>
                    </Avatar>
                    <div className={`flex flex-col ${isOwnMessage ? "items-end" : "items-start"} max-w-[70%]`}>
                      {!isOwnMessage && (
                        <span className="text-xs text-muted-foreground mb-1">{conversation.otherUserName}</span>
                      )}
                      <div className="space-y-2">
                        {message.message_type === "voice" ? (
                          <div
                            className={`rounded-lg px-4 py-2 ${
                              isOwnMessage ? "bg-primary text-primary-foreground" : "bg-muted"
                            }`}
                          >
                            <VoiceMessagePlayer audioUrl={message.content} duration={message.metadata?.duration || 0} />
                          </div>
                        ) : message.content ? (
                          <div
                            className={`rounded-lg px-4 py-2 ${
                              isOwnMessage ? "bg-primary text-primary-foreground" : "bg-muted"
                            }`}
                          >
                            <p className="text-sm break-words">{message.content}</p>
                          </div>
                        ) : null}

                        {/* Render attachments */}
                        {messageAttachments[message.id]?.map((attachment) => (
                          <MessageAttachment key={attachment.id} attachment={attachment} />
                        ))}
                      </div>
                      <div className="flex items-center gap-1 mt-1 flex-wrap">
                        <span className="text-xs text-muted-foreground">{formatMessageTime(message.created_at)}</span>
                        {isOwnMessage && (
                          <MessageStatus status={getMessageStatus(message)} className="text-muted-foreground" />
                        )}
                      </div>

                      {/* Message Reactions */}
                      <div className="mt-2">
                        <MessageReactions messageId={message.id} reactions={message.reactions || {}} />
                      </div>
                    </div>
                    {isOwnMessage && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 opacity-0 group-hover:opacity-100"
                        onClick={() => setMessageToDelete(message.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t p-4 bg-card">
        {isRecordingVoice ? (
          <VoiceMessageRecorder onSend={handleVoiceMessageSend} onCancel={() => setIsRecordingVoice(false)} />
        ) : (
          <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
              <PopoverTrigger asChild>
                <Button type="button" variant="ghost" size="icon">
                  <Smile className="h-5 w-5" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0" align="start">
                <EmojiPicker onEmojiClick={onEmojiClick} />
              </PopoverContent>
            </Popover>

            <ImageUpload
              onImageSelect={() => {}}
              onImageRemove={() => {}}
              onUploadComplete={async (data) => {
                if (!user) return;

                // Create message for attachment
                const messageContent = " ";
                const { data: messageData, error: msgError } = await supabase
                  .from("messages")
                  .insert({
                    sender_id: user.id,
                    recipient_id: conversation.otherUserId,
                    content: messageContent,
                    message_type: "image",
                    status: "sent",
                  })
                  .select()
                  .single();

                if (msgError || !messageData) {
                  toast({ title: "Error", description: "Failed to send image" });
                  return;
                }

                // Create attachment record
                const { error: attachError } = await supabase.from("message_attachments").insert({
                  message_id: messageData.id,
                  uploaded_by: user.id,
                  file_url: data.imageUrl,
                  thumbnail_url: data.thumbnailUrl,
                  file_type: "image",
                  file_name: "image.jpg",
                  file_size: data.metadata.compressedSize,
                  mime_type: "image/jpeg",
                  metadata: data.metadata,
                  original_file_size: data.metadata.originalSize,
                  compression_ratio: data.metadata.compressionRatio,
                });

                if (attachError) {
                  console.error("Attachment error:", attachError);
                }

                loadAllAttachments();
              }}
              messageId={`temp-${Date.now()}`}
              userId={user.id}
            />

            <Button type="button" variant="ghost" size="icon" onClick={() => setIsRecordingVoice(true)}>
              <Mic className="h-5 w-5" />
            </Button>

            <Input
              value={newMessage}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="flex-1"
            />

            <Button type="submit" size="icon" disabled={!newMessage.trim()}>
              <Send className="h-5 w-5" />
            </Button>
          </form>
        )}
      </div>

      {/* Delete confirmation dialog */}
      <AlertDialog open={!!messageToDelete} onOpenChange={() => setMessageToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete message?</AlertDialogTitle>
            <AlertDialogDescription>
              This message will be permanently deleted. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteMessage} disabled={deleting}>
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
