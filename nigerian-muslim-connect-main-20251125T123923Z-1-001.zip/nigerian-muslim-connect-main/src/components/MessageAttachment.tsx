import { ImageAttachment } from "./ImageAttachment";
import { VoiceMessagePlayer } from "./VoiceMessagePlayer";

interface Attachment {
  id: string;
  file_type: string;
  file_url: string;
  thumbnail_url?: string;
  file_name: string;
  file_size: number;
  metadata?: {
    width?: number;
    height?: number;
    originalSize?: number;
    duration?: number;
  };
}

interface MessageAttachmentProps {
  attachment: Attachment;
}

export const MessageAttachment = ({ attachment }: MessageAttachmentProps) => {
  switch (attachment.file_type) {
    case "image":
      return (
        <ImageAttachment
          imageUrl={attachment.file_url}
          thumbnailUrl={attachment.thumbnail_url}
          metadata={attachment.metadata}
          fileName={attachment.file_name}
        />
      );
    
    case "voice":
      return (
        <VoiceMessagePlayer
          audioUrl={attachment.file_url}
          duration={attachment.metadata?.duration}
        />
      );
    
    default:
      return (
        <div className="text-sm text-muted-foreground">
          Unsupported attachment type: {attachment.file_type}
        </div>
      );
  }
};
