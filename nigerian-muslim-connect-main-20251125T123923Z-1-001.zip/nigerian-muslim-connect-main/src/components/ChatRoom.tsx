import { useState, useRef, useEffect } from "react";
import {
  Send,
  Users,
  Smile,
  MoreVertical,
  Heart,
  Edit2,
  Trash2,
  Check,
  X,
  Mic,
  FileText,
  RefreshCw,
  AlertTriangle,
} from "lucide-react";
import { VoiceMessageRecorder } from "./VoiceMessageRecorder";
import { VoiceMessagePlayer } from "./VoiceMessagePlayer";
import { uploadVoiceMessage, recordVoiceAttachment } from "@/utils/voiceMessageUpload";
import { MessageStatus } from "./MessageStatus";
import { ImageUpload } from "./ImageUpload";
import { MessageAttachment } from "./MessageAttachment";
import { MessageReactions } from "./MessageReactions";
import { VideoCallButton } from "./VideoCallButton";
import { VideoCallEmbed } from "./VideoCallEmbed";
import { useActiveCall } from "@/hooks/useActiveCall";
import { logger } from "@/lib/logger";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { HeroButton } from "@/components/ui/hero-button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

interface Message {
  id: string;
  user: string;
  message: string;
  time: string;
  location: string;
  likes: number;
  isOwn?: boolean;
  edited_at?: string;
  is_deleted?: boolean;
  sender_id?: string;
  status?: "sending" | "sent" | "delivered" | "read";
  reactions?: Record<string, string[]>;
  message_type?: string;
}

interface OnlineUser {
  name: string;
  location: string;
  status: "online" | "away";
}

const ChatRoom = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageAttachments, setMessageAttachments] = useState<Record<string, any[]>>({});

  const [newMessage, setNewMessage] = useState("");
  const [editingMessage, setEditingMessage] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [onlineUsers] = useState<OnlineUser[]>([
    { name: "Aisha M.", location: "Chicago, IL", status: "online" },
    { name: "Ibrahim K.", location: "Detroit, MI", status: "online" },
    { name: "Fatima O.", location: "Minneapolis, MN", status: "online" },
    { name: "Musa A.", location: "Cleveland, OH", status: "online" },
    { name: "Khadija S.", location: "Indianapolis, IN", status: "away" },
    { name: "Yusuf H.", location: "Milwaukee, WI", status: "online" },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { activeCallRoom, callType, isInCall, endCall } = useActiveCall();

  // Authentication guard - early return if not authenticated
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen p-8">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Please sign in to access the community chat.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load attachments for all messages with fresh signed URLs
  const loadAllAttachments = async () => {
    try {
      const { data, error } = await supabase
        .from("message_attachments")
        .select("*")
        .order("created_at", { ascending: true });

      if (error) throw error;

      const attachmentsByMessage: Record<string, any[]> = {};
      
      // Generate fresh signed URLs for each attachment
      for (const attachment of data || []) {
        // Extract the storage path from the file_url (remove the base URL if present)
        const urlPath = attachment.file_url.split('/message-attachments/').pop() || attachment.file_url;
        
        // Generate fresh signed URL (valid for 1 hour)
        const { data: signedData } = await supabase.storage
          .from("message-attachments")
          .createSignedUrl(urlPath, 3600);
        
        // Generate fresh thumbnail URL if exists
        let freshThumbnailUrl = attachment.thumbnail_url;
        if (attachment.thumbnail_url) {
          const thumbPath = attachment.thumbnail_url.split('/message-attachments/').pop() || attachment.thumbnail_url;
          const { data: thumbSignedData } = await supabase.storage
            .from("message-attachments")
            .createSignedUrl(thumbPath, 3600);
          freshThumbnailUrl = thumbSignedData?.signedUrl || attachment.thumbnail_url;
        }

        const freshAttachment = {
          ...attachment,
          file_url: signedData?.signedUrl || attachment.file_url,
          thumbnail_url: freshThumbnailUrl,
        };

        if (!attachmentsByMessage[attachment.message_id]) {
          attachmentsByMessage[attachment.message_id] = [];
        }
        attachmentsByMessage[attachment.message_id].push(freshAttachment);
      }

      setMessageAttachments(attachmentsByMessage);
    } catch (error) {
      console.error("Error loading attachments:", error);
    }
  };

  // Load messages from database and set up real-time updates
  useEffect(() => {
    const loadMessages = async () => {
      try {
        const { data, error } = await supabase
          .from("messages")
          .select(
            `
            id,
            content,
            created_at,
            edited_at,
            is_deleted,
            sender_id,
            reactions,
            message_type,
            profiles(full_name, location)
          `,
          )
          .eq("is_deleted", false)
          .order("created_at", { ascending: true });

        if (error) {
          return;
        }

        const formattedMessages: Message[] = data.map((msg: any) => ({
          id: msg.id,
          user: msg.profiles?.full_name || `User ${msg.sender_id.slice(0, 8)}`,
          message: msg.content,
          time: new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          location: msg.profiles?.location || "Location not set",
          likes: 0, // We'll implement likes later
          isOwn: msg.sender_id === user?.id,
          edited_at: msg.edited_at
            ? new Date(msg.edited_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
            : undefined,
          is_deleted: msg.is_deleted,
          sender_id: msg.sender_id,
          reactions: (msg.reactions as Record<string, string[]>) || {},
          message_type: msg.message_type,
        }));

        setMessages(formattedMessages);
        await loadAllAttachments();
      } catch (error) {
        // Error loading messages - handled silently in production
      }
    };

    if (user) {
      loadMessages();

      // Set up real-time subscription for messages
      const channel = supabase
        .channel("messages")
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "messages",
          },
          (payload) => {
            const newMessage = payload.new as any;
            const formattedMessage: Message = {
              id: newMessage.id,
              user: user?.user_metadata?.full_name || `User ${newMessage.sender_id.slice(0, 8)}`,
              message: newMessage.content,
              time: new Date(newMessage.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              location: user?.user_metadata?.location || "Location not set",
              likes: 0,
              isOwn: newMessage.sender_id === user?.id,
              sender_id: newMessage.sender_id,
              reactions: (newMessage.reactions as Record<string, string[]>) || {},
              message_type: newMessage.message_type,
            };
            setMessages((prev) => [...prev, formattedMessage]);
          },
        )
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "messages",
          },
          (payload) => {
            const updatedMessage = payload.new as any;
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === updatedMessage.id
                  ? {
                      ...msg,
                      message: updatedMessage.is_deleted ? "This message has been deleted" : updatedMessage.content,
                      edited_at: updatedMessage.edited_at
                        ? new Date(updatedMessage.edited_at).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })
                        : undefined,
                      is_deleted: updatedMessage.is_deleted,
                      reactions: (updatedMessage.reactions as Record<string, string[]>) || msg.reactions || {},
                    }
                  : msg,
              ),
            );
          },
        )
        .subscribe();

      // Set up real-time subscription for attachments
      const attachmentsChannel = supabase
        .channel("message_attachments")
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "message_attachments",
          },
          (payload) => {
            const newAttachment = payload.new as any;
            setMessageAttachments((prev) => ({
              ...prev,
              [newAttachment.message_id]: [...(prev[newAttachment.message_id] || []), newAttachment],
            }));
          },
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
        supabase.removeChannel(attachmentsChannel);
      };
    }
  }, [user]);

  const handleSendMessage = async () => {
    // Strengthen authentication check
    if (!newMessage.trim() || !user?.id) {
      toast({
        title: "Cannot send message",
        description: "Please ensure you are signed in.",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase.from("messages").insert({
        content: newMessage.trim(),
        sender_id: user.id,
        message_type: "text",
      });

      if (error) {
        console.error("Error sending message:", error);
        toast({
          title: "Failed to send",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      setNewMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Failed to send",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  const handleVoiceMessageSend = async (audioBlob: Blob, duration: number, mimeType: string) => {
    if (!user?.id) return;

    try {
      // Step 1: Create message record first to get real UUID
      const { data: messageData, error: messageError } = await supabase
        .from("messages")
        .insert({
          sender_id: user.id,
          content: "", // Will be updated with file path
          message_type: "voice",
          metadata: { duration, mimeType },
        })
        .select()
        .single();

      if (messageError) throw messageError;

      // Step 2: Upload voice file using the real message UUID
      const filePath = await uploadVoiceMessage(audioBlob, messageData.id, user.id, mimeType);

      // Step 3: Record attachment metadata
      await recordVoiceAttachment(messageData.id, filePath, mimeType, audioBlob.size, user.id);

      // Step 4: Update message content with file path
      const { error: updateError } = await supabase
        .from("messages")
        .update({ content: filePath })
        .eq("id", messageData.id);

      if (updateError) throw updateError;

      setIsRecordingVoice(false);
      toast({
        title: "Voice message sent",
        description: "Your voice message has been sent to the chat.",
      });
    } catch (error: any) {
      console.error("Error sending voice message:", error);
      toast({
        title: "Failed to send",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleLikeMessage = (messageId: string) => {
    setMessages(messages.map((msg) => (msg.id === messageId ? { ...msg, likes: msg.likes + 1 } : msg)));
  };

  const handleEditMessage = (messageId: string, currentText: string) => {
    setEditingMessage(messageId);
    setEditText(currentText);
  };

  const handleSaveEdit = async (messageId: string) => {
    if (!editText.trim() || !user) return;

    try {
      const { error } = await supabase
        .from("messages")
        .update({
          content: editText.trim(),
          edited_at: new Date().toISOString(),
        })
        .eq("id", messageId)
        .eq("sender_id", user.id);

      if (error) {
        return;
      }

      // Update will be handled by real-time subscription
      setEditingMessage(null);
      setEditText("");
    } catch (error) {
      // Error updating message - handled silently in production
    }
  };

  const handleCancelEdit = () => {
    setEditingMessage(null);
    setEditText("");
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from("messages")
        .update({ is_deleted: true })
        .eq("id", messageId)
        .eq("sender_id", user.id);

      if (error) {
        return;
      }

      // Update will be handled by real-time subscription
    } catch (error) {
      // Error deleting message - handled silently in production
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/30 pt-4">
      {/* Active Call Overlay */}
      {activeCallRoom && (
        <VideoCallEmbed
          roomUrl="https://global-muslims-connec.daily.co/gmc-main-room"
          onLeave={endCall}
          userName={user?.user_metadata?.full_name || "User"}
          isAudioOnly={callType === "audio"}
        />
      )}

      <div className="container mx-auto px-4 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-6rem)]">
          {/* Online Users Sidebar */}
          <div className="lg:col-span-1">
            <Card className="h-full shadow-lg">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="text-islamic-green" size={20} />
                  Online ({onlineUsers.filter((u) => u.status === "online").length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[calc(100vh-12rem)]">
                  <div className="p-4 space-y-3">
                    {onlineUsers.map((user, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/50 transition-colors"
                      >
                        <div className="relative">
                          <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center text-white font-semibold text-sm">
                            {user.name.charAt(0)}
                          </div>
                          <div
                            className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${
                              user.status === "online" ? "bg-green-500" : "bg-yellow-500"
                            }`}
                          ></div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{user.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{user.location}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Main Chat Area */}
          <div className="lg:col-span-3">
            <Card className="h-full shadow-lg flex flex-col">
              <CardHeader className="pb-3 border-b border-border/50">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">Community Chat Room</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      Nigerian Islamic Communities of America Discussion • Be respectful and kind
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <VideoCallButton groupId="community-chat" recipientName="Community Chat" variant="video" />
                    <Badge className="bg-green-100 text-green-800">
                      {onlineUsers.filter((u) => u.status === "online").length} online
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="p-2 hover:bg-secondary/50 rounded-lg transition-colors">
                          <MoreVertical size={16} />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-56 bg-popover z-50" align="end">
                        <DropdownMenuItem onClick={() => window.open("/community-guidelines", "_blank")}>
                          <FileText className="mr-2 h-4 w-4" />
                          <span>Community Guidelines</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => window.location.reload()}>
                          <RefreshCw className="mr-2 h-4 w-4" />
                          <span>Refresh Chat</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => {
                            toast({
                              title: "Report Issue",
                              description: "Please contact support if you notice any issues.",
                            });
                          }}
                        >
                          <AlertTriangle className="mr-2 h-4 w-4" />
                          <span>Report Issue</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>

              {/* Messages Area */}
              <CardContent className="flex-1 p-0 overflow-hidden">
                <ScrollArea className="h-[calc(100vh-16rem)] p-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div key={message.id} className={`flex gap-3 ${message.isOwn ? "flex-row-reverse" : ""}`}>
                        <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                          {message.user.charAt(0)}
                        </div>
                        <div className={`flex-1 max-w-md ${message.isOwn ? "text-right" : ""}`}>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{message.user}</span>
                            <span className="text-xs text-muted-foreground">{message.time}</span>
                            <span className="text-xs text-muted-foreground">• {message.location}</span>
                            {message.edited_at && (
                              <span className="text-xs text-muted-foreground italic">(edited)</span>
                            )}
                          </div>

                          {editingMessage === message.id ? (
                            // Edit mode
                            <div className="space-y-2">
                              <Input
                                value={editText}
                                onChange={(e) => setEditText(e.target.value)}
                                className="text-sm"
                                onKeyPress={(e) => {
                                  if (e.key === "Enter") handleSaveEdit(message.id);
                                  if (e.key === "Escape") handleCancelEdit();
                                }}
                                autoFocus
                              />
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleSaveEdit(message.id)}
                                  className="flex items-center gap-1 px-2 py-1 text-xs bg-green-100 text-green-800 rounded hover:bg-green-200 transition-colors"
                                >
                                  <Check size={12} />
                                  Save
                                </button>
                                <button
                                  onClick={handleCancelEdit}
                                  className="flex items-center gap-1 px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded hover:bg-gray-200 transition-colors"
                                >
                                  <X size={12} />
                                  Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            // Display mode
                            <div className="relative group">
                              <div
                                className={`p-3 rounded-lg ${
                                  message.isOwn ? "bg-gradient-primary text-white ml-auto" : "bg-secondary/50"
                                } ${message.is_deleted ? "opacity-60 italic" : ""}`}
                              >
                                {message.message_type !== "image" && message.message && (
                                  <p className="text-sm leading-relaxed">{message.message}</p>
                                )}

                                {/* Display attachments */}
                                {messageAttachments[message.id]?.map((attachment) => (
                                  <div key={attachment.id} className={message.message_type !== "image" ? "mt-2" : ""}>
                                    <MessageAttachment attachment={attachment} />
                                  </div>
                                ))}
                              </div>

                              {/* Message options for own messages */}
                              {message.isOwn && !message.is_deleted && (
                                <div
                                  className={`absolute top-2 ${message.isOwn ? "left-2" : "right-2"} opacity-0 group-hover:opacity-100 transition-opacity`}
                                >
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <button className="p-1 rounded hover:bg-black/10 transition-colors">
                                        <MoreVertical
                                          size={14}
                                          className={message.isOwn ? "text-white" : "text-gray-600"}
                                        />
                                      </button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="start" className="w-32">
                                      <DropdownMenuItem
                                        onClick={() => handleEditMessage(message.id, message.message)}
                                        className="flex items-center gap-2 text-sm"
                                      >
                                        <Edit2 size={12} />
                                        Edit
                                      </DropdownMenuItem>
                                      <AlertDialog>
                                        <AlertDialogTrigger asChild>
                                          <DropdownMenuItem
                                            onSelect={(e) => e.preventDefault()}
                                            className="flex items-center gap-2 text-sm text-red-600 focus:text-red-600"
                                          >
                                            <Trash2 size={12} />
                                            Delete
                                          </DropdownMenuItem>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent>
                                          <AlertDialogHeader>
                                            <AlertDialogTitle>Delete Message</AlertDialogTitle>
                                            <AlertDialogDescription>
                                              Are you sure you want to delete this message? This action cannot be
                                              undone.
                                            </AlertDialogDescription>
                                          </AlertDialogHeader>
                                          <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction
                                              onClick={() => handleDeleteMessage(message.id)}
                                              className="bg-red-600 hover:bg-red-700"
                                            >
                                              Delete
                                            </AlertDialogAction>
                                          </AlertDialogFooter>
                                        </AlertDialogContent>
                                      </AlertDialog>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </div>
                              )}
                            </div>
                          )}

                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            {message.isOwn && message.status && (
                              <MessageStatus status={message.status} className="text-muted-foreground" />
                            )}
                          </div>

                          {/* Message Reactions */}
                          {!message.is_deleted && (
                            <div className="mt-2">
                              <MessageReactions messageId={message.id} reactions={message.reactions || {}} />
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              </CardContent>

              {/* Message Input */}
              <div className="p-4 border-t border-border/50">
                <div className="flex gap-3">
                  <div className="flex-1 relative">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Type your message... (Be respectful and kind)"
                      className="pr-12 h-12 text-base"
                    />
                    <button className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-secondary/50 rounded transition-colors">
                      <Smile size={18} className="text-muted-foreground" />
                    </button>
                  </div>
                  <ImageUpload
                    onImageSelect={() => {}}
                    onImageRemove={() => {}}
                    onUploadComplete={async (data) => {
                      if (!user?.id) {
                        data.reset();
                        return;
                      }

                      try {
                        const { data: messageData, error: messageError } = await supabase
                          .from("messages")
                          .insert({
                            sender_id: user.id,
                            content: "",
                            message_type: "image",
                          })
                          .select()
                          .single();

                        if (messageError) throw messageError;

                        const { error: attachmentError } = await supabase.from("message_attachments").insert({
                          message_id: messageData.id,
                          file_type: "image",
                          file_url: data.imageUrl,
                          thumbnail_url: data.thumbnailUrl,
                          file_name: "image.jpg",
                          file_size: data.metadata.originalSize || 0,
                          uploaded_by: user.id,
                          metadata: data.metadata,
                        });

                        if (attachmentError) throw attachmentError;

                        // Immediately update local state for sender
                        setMessageAttachments((prev) => ({
                          ...prev,
                          [messageData.id]: [
                            {
                              id: crypto.randomUUID(),
                              message_id: messageData.id,
                              file_type: "image",
                              file_url: data.imageUrl,
                              thumbnail_url: data.thumbnailUrl,
                              file_name: "image.jpg",
                              file_size: data.metadata.originalSize || 0,
                              metadata: data.metadata,
                            },
                          ],
                        }));

                        toast({
                          title: "Image sent",
                          description: "Your image has been shared in the chat.",
                        });
                        data.reset();
                      } catch (error: any) {
                        console.error("Error sending image:", error);
                        toast({
                          title: "Failed to send",
                          description: error.message,
                          variant: "destructive",
                        });
                        data.reset();
                      }
                    }}
                    messageId={`temp-${Date.now()}`}
                    userId={user?.id || ""}
                  />
                  <HeroButton
                    type="button"
                    onClick={() => setIsRecordingVoice(true)}
                    size="lg"
                    variant="secondary"
                    className="text-islamic-green hover:text-white"
                    aria-label="Record voice message"
                  >
                    <Mic size={18} />
                  </HeroButton>
                  <HeroButton onClick={handleSendMessage} disabled={!newMessage.trim()} size="lg">
                    <Send size={18} />
                  </HeroButton>
                </div>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  Remember: This is a sacred space for our community. Please maintain Islamic etiquette.
                </p>
              </div>
            </Card>
          </div>
        </div>

        {/* Voice Message Recorder */}
        {isRecordingVoice && (
          <VoiceMessageRecorder onSend={handleVoiceMessageSend} onCancel={() => setIsRecordingVoice(false)} />
        )}
      </div>
    </div>
  );
};

export default ChatRoom;
