import { useState, useRef, useEffect } from "react";
import { BookOpen, Star, Heart } from "lucide-react";
import QuranPlayer from "./quran/QuranPlayer";
import { Card, CardContent } from "@/components/ui/card";
import { popularSurahs, reciters, Reciter } from "@/data/quranData";
import { useQuranPlayer } from "@/hooks/useQuranPlayer";
import { toast } from "@/hooks/use-toast";

const QuranSection = () => {
  const playerRef = useRef<HTMLDivElement>(null);
  const [selectedReciter, setSelectedReciter] = useState<Reciter>(reciters[1]); // Default to Al-Sudais
  const [hasAutoLoaded, setHasAutoLoaded] = useState(false);

  const quranPlayerState = useQuranPlayer();

  // Auto-load Al-Fatihah on desktop only (iOS requires user interaction)
  useEffect(() => {
    // Check if not mobile/iOS
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    
    if (!isMobile && !hasAutoLoaded && !quranPlayerState.currentSurah) {
      const alFatihah = popularSurahs.find(s => s.number === 1);
      if (alFatihah) {
        quranPlayerState.loadSurah(alFatihah, selectedReciter);
        setHasAutoLoaded(true);
      }
    }
  }, [hasAutoLoaded, quranPlayerState.currentSurah]);

  const handlePopularSurahClick = (surah: typeof popularSurahs[0]) => {
    quranPlayerState.loadSurah(surah, selectedReciter);
    toast({
      title: "Loading Surah",
      description: `${surah.englishName} - ${surah.name}`,
    });
    
    // Scroll to player
    setTimeout(() => {
      playerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  return (
    <section id="quran-section" className="py-16 px-4 bg-gradient-to-br from-background to-muted/30 relative overflow-hidden">
      {/* Islamic geometric pattern background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234ade80' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="container mx-auto max-w-7xl relative z-10">
        {/* Header */}
        <div className="text-center mb-12 space-y-4">
          <div className="flex items-center justify-center gap-2 mb-4">
            <BookOpen className="h-8 w-8 text-islamic-gold animate-pulse" />
            <Star className="h-5 w-5 text-islamic-gold" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-islamic-green to-islamic-gold bg-clip-text text-transparent">
            Listen to the Holy Quran
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Experience spiritual tranquility through beautiful Quranic recitations by world-renowned reciters
          </p>
        </div>

        {/* Main Player */}
        <div ref={playerRef} className="mb-12">
          <QuranPlayer 
            {...quranPlayerState}
            selectedReciter={selectedReciter}
            onReciterChange={setSelectedReciter}
          />
        </div>

        {/* Popular Surahs Grid */}
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-center flex items-center justify-center gap-2">
            <Heart className="h-5 w-5 text-islamic-gold" />
            Popular Surahs
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {popularSurahs.map((surah) => (
              <button
                key={surah.number}
                onClick={() => handlePopularSurahClick(surah)}
                className="w-full text-left touch-manipulation cursor-pointer active:opacity-90"
                style={{ 
                  WebkitTapHighlightColor: 'rgba(0,0,0,0)',
                  WebkitTouchCallout: 'none',
                  touchAction: 'manipulation',
                  minHeight: '44px',
                  minWidth: '44px'
                }}
              >
                <Card className="group hover:shadow-islamic transition-all duration-300 bg-card/50 backdrop-blur-sm border-islamic-gold/20 hover:border-islamic-gold/40 hover:scale-105 active:scale-95">
                  <CardContent className="p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-islamic-green to-islamic-gold flex items-center justify-center text-white font-bold">
                        {surah.number}
                      </div>
                      <Star className="h-4 w-4 text-islamic-gold opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-2xl font-serif text-islamic-gold">{surah.name}</p>
                      <p className="font-semibold text-foreground">{surah.englishName}</p>
                      <p className="text-xs text-muted-foreground">{surah.englishTranslation}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2">
                        <span>{surah.ayahs} verses</span>
                        <span>•</span>
                        <span>{surah.revelation}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </button>
            ))}
          </div>
        </div>

        {/* Inspirational Quote */}
        <div className="mt-12 text-center">
          <Card className="max-w-3xl mx-auto bg-gradient-to-r from-islamic-green/10 to-islamic-gold/10 border-islamic-gold/20">
            <CardContent className="p-6">
              <p className="text-lg italic text-muted-foreground">
                "Indeed, it is We who sent down the Quran and indeed, We will be its guardian."
              </p>
              <p className="text-sm font-semibold text-islamic-gold mt-2">- Surah Al-Hijr (15:9)</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default QuranSection;
