import { useState } from "react";
import tariqIslamLogo from "@/assets/tariq-islam-logo.jpeg";
import { Link } from "react-router-dom";
import { Briefcase, ShoppingBag, MessageSquare } from "lucide-react";
import { FeedbackDialog } from "./FeedbackDialog";
import { Button } from "./ui/button";

const Footer = () => {
  const [feedbackOpen, setFeedbackOpen] = useState(false);

  return (
    <footer className="py-12 border-t border-border bg-card/50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand Section */}
          <div className="flex flex-col items-center md:items-start gap-4">
            <img 
              src={tariqIslamLogo} 
              alt="Tariq Islam Logo" 
              className="w-16 h-16 object-contain rounded-lg"
            />
            <p className="text-sm text-muted-foreground font-bold text-center md:text-left">
              Please respect our community
            </p>
          </div>

          {/* Community Links */}
          <div className="text-center">
            <h3 className="font-semibold text-foreground mb-3">Community</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/mosques" className="text-sm text-muted-foreground hover:text-islamic-green transition-colors">
                  Mosques
                </Link>
              </li>
              <li>
                <Link to="/events" className="text-sm text-muted-foreground hover:text-islamic-green transition-colors">
                  Events
                </Link>
              </li>
              <li>
                <Link to="/chat" className="text-sm text-muted-foreground hover:text-islamic-green transition-colors">
                  Chat Room
                </Link>
              </li>
              <li>
                <Link to="/community-guidelines" className="text-sm text-muted-foreground hover:text-islamic-green transition-colors">
                  Community Guidelines
                </Link>
              </li>
            </ul>
          </div>

          {/* Business Links */}
          <div className="text-center">
            <h3 className="font-semibold text-foreground mb-3">For Businesses</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  to="/partnerships" 
                  className="text-sm text-muted-foreground hover:text-islamic-green transition-colors inline-flex items-center justify-center gap-2"
                >
                  <Briefcase size={16} />
                  Advertise With Us
                </Link>
              </li>
              <li>
                <Link 
                  to="/submit-ad" 
                  className="text-sm text-muted-foreground hover:text-islamic-green transition-colors inline-flex items-center justify-center gap-2"
                >
                  <ShoppingBag size={16} />
                  Business Listings
                </Link>
              </li>
            </ul>
          </div>

          {/* Support Section */}
          <div className="text-center md:text-right">
            <h3 className="font-semibold text-foreground mb-3">Support</h3>
            <ul className="space-y-2">
              <li>
                <Button
                  variant="link"
                  onClick={() => setFeedbackOpen(true)}
                  className="text-sm text-muted-foreground hover:text-islamic-green transition-colors inline-flex items-center justify-center md:justify-end gap-2 p-0 h-auto"
                >
                  <MessageSquare size={16} />
                  Contact Us
                </Button>
              </li>
              <li>
                <Link 
                  to="/community-guidelines" 
                  className="text-sm text-muted-foreground hover:text-islamic-green transition-colors inline-flex items-center justify-center md:justify-end gap-2"
                >
                  Community Guidelines
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <FeedbackDialog open={feedbackOpen} onOpenChange={setFeedbackOpen} />

        {/* Bottom Copyright */}
        <div className="pt-6 border-t border-border/50 text-center">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Tariq Islam. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
