import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Smartphone, QrCode, Shield, Star } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const MobileDownload = () => {
  const [showQR, setShowQR] = useState(false);

  const isMobileDevice = () => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  };

  const downloadAPK = () => {
    // For now, this would link to your hosted APK file
    // In production, you'd host the APK file and link to it
    const apkUrl = "/nigerian-muslim-connect.apk"; // This would be your actual APK file
    const link = document.createElement('a');
    link.href = apkUrl;
    link.download = 'nigerian-muslim-connect.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Download Our Mobile App
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Stay connected with the Muslim community on the go. Access prayer times, events, and community features from your mobile device.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* App Features Card */}
          <Card className="bg-card/50 backdrop-blur-sm border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="h-6 w-6 text-primary" />
                Mobile Features
              </CardTitle>
              <CardDescription>
                Everything you love about our website, optimized for mobile
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Star className="h-5 w-5 text-yellow-500" />
                <span className="text-sm">Real-time prayer times with location</span>
              </div>
              <div className="flex items-center gap-3">
                <Star className="h-5 w-5 text-yellow-500" />
                <span className="text-sm">Community chat and messaging</span>
              </div>
              <div className="flex items-center gap-3">
                <Star className="h-5 w-5 text-yellow-500" />
                <span className="text-sm">Event notifications</span>
              </div>
              <div className="flex items-center gap-3">
                <Star className="h-5 w-5 text-yellow-500" />
                <span className="text-sm">Offline mosque directory</span>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-green-500" />
                <span className="text-sm">Secure and private messaging</span>
              </div>
            </CardContent>
          </Card>

          {/* Download Card */}
          <Card className="bg-card/50 backdrop-blur-sm border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-6 w-6 text-primary" />
                Download for Android
              </CardTitle>
              <CardDescription>
                Get the latest version of our mobile app
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-muted-foreground">
                <p className="mb-2">Version 1.0.0</p>
                <p className="mb-4">Size: ~15 MB</p>
                <p className="mb-4">Requires Android 7.0 or higher</p>
              </div>
              
              <div className="space-y-3">
                <Button 
                  onClick={downloadAPK}
                  className="w-full"
                  size="lg"
                >
                  <Download className="mr-2 h-5 w-5" />
                  Download APK
                </Button>

                <Dialog open={showQR} onOpenChange={setShowQR}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full">
                      <QrCode className="mr-2 h-4 w-4" />
                      Show QR Code
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Scan to Download</DialogTitle>
                      <DialogDescription>
                        Scan this QR code with your mobile device to download the app
                      </DialogDescription>
                    </DialogHeader>
                    <div className="flex justify-center p-6">
                      <div className="w-48 h-48 bg-muted rounded-lg flex items-center justify-center">
                        <QrCode className="h-32 w-32 text-muted-foreground" />
                        <span className="sr-only">QR Code for app download</span>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {isMobileDevice() && (
                <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg">
                  <p className="font-medium mb-1">Installation Note:</p>
                  <p>You may need to enable "Install from unknown sources" in your Android settings to install this APK.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <p className="text-sm text-muted-foreground">
            Coming soon to Google Play Store
          </p>
        </div>
      </div>
    </section>
  );
};

export default MobileDownload;