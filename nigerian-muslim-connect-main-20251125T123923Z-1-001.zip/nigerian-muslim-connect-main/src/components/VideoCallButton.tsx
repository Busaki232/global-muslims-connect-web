import { useState } from 'react';
import { Video, Phone, Loader2 } from 'lucide-react';
import { Button } from './ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useActiveCall } from '@/hooks/useActiveCall';
import { toast } from 'sonner';

interface VideoCallButtonProps {
  conversationId?: string;
  groupId?: string;
  recipientName: string;
  variant: 'video' | 'audio';
}

export const VideoCallButton = ({
  conversationId,
  groupId,
  recipientName,
  variant,
}: VideoCallButtonProps) => {
  const [loading, setLoading] = useState(false);
  const { startCall } = useActiveCall();

  const handleStartCall = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-daily-room', {
        body: {
          conversationId,
          groupId,
          callType: variant,
        },
      });

      if (error) throw error;

      if (data.roomUrl) {
        startCall(data.roomUrl, variant, recipientName);
        toast.success(`${variant === 'video' ? 'Video' : 'Voice'} call started`);

        // Send push notification to recipient(s)
        const { data: { user } } = await supabase.auth.getUser();
        
        if (user) {
          const { data: callerProfile } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('user_id', user.id)
            .single();

          let recipientIds: string[] = [];

          // Get recipient IDs based on conversation or group
          if (conversationId) {
            const { data: conversation } = await supabase
              .from('conversations')
              .select('user1_id, user2_id')
              .eq('id', conversationId)
              .single();
            
            if (conversation) {
              recipientIds = [
                conversation.user1_id === user.id ? conversation.user2_id : conversation.user1_id
              ];
            }
          } else if (groupId) {
            const { data: members } = await supabase
              .from('group_members')
              .select('user_id')
              .eq('group_id', groupId)
              .neq('user_id', user.id);
            
            if (members) {
              recipientIds = members.map(m => m.user_id);
            }
          }

          // Send push notification
          if (recipientIds.length > 0) {
            supabase.functions.invoke('send-push-notification', {
              body: {
                userIds: recipientIds,
                title: `Incoming ${variant === 'video' ? 'Video' : 'Voice'} Call`,
                body: `${callerProfile?.full_name || 'Someone'} is calling you`,
                data: {
                  type: 'call',
                  callType: variant,
                  conversationId,
                  groupId,
                  callUrl: data.roomUrl,
                  url: '/',
                },
                actions: [
                  { action: 'join_call', title: 'Join' },
                ],
                priority: 4, // Urgent
              },
            }).catch(err => console.error('Failed to send call notification:', err));
          }
        }
      } else {
        throw new Error('No room URL returned');
      }
    } catch (error: any) {
      console.error('Error starting call:', error);
      toast.error(error.message || 'Failed to start call');
    } finally {
      setLoading(false);
    }
  };

  const Icon = variant === 'video' ? Video : Phone;

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={handleStartCall}
      disabled={loading}
      title={`Start ${variant} call`}
    >
      {loading ? (
        <Loader2 className="h-5 w-5 animate-spin" />
      ) : (
        <Icon className="h-5 w-5" />
      )}
    </Button>
  );
};
