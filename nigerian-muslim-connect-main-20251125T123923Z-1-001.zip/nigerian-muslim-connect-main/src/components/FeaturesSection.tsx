import { Compass, MapPin, Calendar, Users, BookOpen, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { HeroButton } from "@/components/ui/hero-button";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const FeaturesSection = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleQiblaFinder = () => {
    const prayerTimesSection = document.getElementById('prayer-times');
    if (prayerTimesSection) {
      prayerTimesSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
      toast({
        title: "Qibla Finder",
        description: "Use the 'Find Qibla' button in the Prayer Times section",
      });
    } else {
      navigate('/');
      setTimeout(() => {
        const section = document.getElementById('prayer-times');
        section?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 300);
    }
  };

  const handleMosqueLocator = () => {
    navigate('/mosques');
  };

  const handleIslamicCalendar = () => {
    navigate('/islamic-calendar');
  };

  const handleCommunityNetwork = () => {
    if (!user) {
      toast({
        title: "Sign in Required",
        description: "Please sign in to join our community network.",
      });
      navigate('/auth');
      return;
    }
    navigate('/chat');
  };

  const handleIslamicLearning = () => {
    const quranSection = document.querySelector('#quran-section');
    if (quranSection) {
      quranSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      toast({
        title: "Islamic Learning",
        description: "Explore the Quran section and listen to recitations",
      });
    } else {
      navigate('/');
      setTimeout(() => {
        const section = document.querySelector('#quran-section');
        section?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 300);
    }
  };

  const handleCulturalHeritage = () => {
    const communitySection = document.querySelector('#community-section');
    if (communitySection) {
      communitySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      toast({
        title: "Cultural Heritage",
        description: "Discover our community and cultural events",
      });
    } else {
      navigate('/');
      setTimeout(() => {
        const section = document.querySelector('#community-section');
        section?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 300);
    }
  };

  const features = [
    {
      icon: Compass,
      title: "Qibla Finder",
      description: "Accurate Qibla direction wherever you are in the world using GPS technology",
      color: "text-prayer-blue",
      onClick: handleQiblaFinder
    },
    {
      icon: MapPin,
      title: "Mosque Locator",
      description: "Find nearby mosques, Islamic centers, and halal restaurants in your area",
      color: "text-islamic-green",
      onClick: handleMosqueLocator
    },
    {
      icon: Calendar,
      title: "Islamic Calendar",
      description: "Never miss important Islamic dates, holidays, and community events",
      color: "text-islamic-gold",
      onClick: handleIslamicCalendar
    },
    {
      icon: Users,
      title: "Community Network",
      description: "Connect with Muslims in your city and around the world",
      color: "text-nigerian-green",
      onClick: handleCommunityNetwork
    },
    {
      icon: BookOpen,
      title: "Islamic Learning",
      description: "Access Quran, Hadith, and Islamic educational resources in multiple languages",
      color: "text-prayer-blue",
      onClick: handleIslamicLearning
    },
    {
      icon: Heart,
      title: "Cultural Heritage",
      description: "Celebrate Nigerian Islamic traditions and share cultural experiences",
      color: "text-islamic-gold",
      onClick: handleCulturalHeritage
    }
  ];

  const handleJoinCommunity = () => {
    if (!user) {
      toast({
        title: "Sign in Required",
        description: "Please sign in to join our community chat.",
        variant: "default",
      });
      navigate("/auth");
      return;
    }
    navigate("/chat");
  };

  const handleExploreFeatures = () => {
    navigate("/mosques");
  };

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Everything You Need for Your Islamic Journey
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Comprehensive tools and community features designed for Muslims all over the world
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <button
                key={index}
                onClick={feature.onClick}
                className="w-full text-left touch-manipulation cursor-pointer active:opacity-70"
                style={{ 
                  WebkitTapHighlightColor: 'rgba(0,0,0,0)',
                  WebkitTouchCallout: 'none',
                  minHeight: '44px',
                  minWidth: '44px'
                }}
              >
                <Card className="group hover:shadow-islamic transition-all duration-300 hover:-translate-y-1 active:translate-y-0 border-border/50 h-full">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-gradient-primary rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                      <IconComponent className="text-white" size={28} />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </button>
            );
          })}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-hero rounded-2xl p-8 md:p-12 text-white max-w-4xl mx-auto shadow-2xl border-2 border-white/20 backdrop-blur-sm animate-in fade-in slide-in-from-bottom-4 duration-700">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Ready to Join Our Community?
            </h3>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Start your journey with thousands of Muslims worldwide who have found 
              their spiritual home through our platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <HeroButton 
                size="lg" 
                className="bg-white text-islamic-green hover:bg-white/90 shadow-none touch-manipulation"
                onClick={handleJoinCommunity}
              >
                <Users className="mr-2" />
                Join Community Now
              </HeroButton>
              <HeroButton 
                variant="outline" 
                size="lg"
                className="border-white/80 border-2 text-white bg-white/10 hover:bg-white hover:text-islamic-green backdrop-blur-sm touch-manipulation"
                onClick={handleExploreFeatures}
              >
                <BookOpen className="mr-2" />
                Explore Features
              </HeroButton>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;