import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useContentModeration } from '@/hooks/useContentModeration';

const createPostSchema = z.object({
  content: z.string().trim().min(10, 'Post content must be at least 10 characters').max(1000, 'Post content must be less than 1000 characters'),
  location: z.string().trim().max(100, 'Location must be less than 100 characters').optional(),
});

type CreatePostData = z.infer<typeof createPostSchema>;

interface CreatePostFormProps {
  onSuccess?: () => void;
  onCancel?: () => void;
}

export const CreatePostForm = ({ 
  onSuccess, 
  onCancel 
}: CreatePostFormProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const { checkContent, createAutoFlaggedReport } = useContentModeration();

  const form = useForm<CreatePostData>({
    resolver: zodResolver(createPostSchema),
    defaultValues: {
      content: '',
      location: '',
    },
  });

  const onSubmit = async (data: CreatePostData) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to create a post.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Check content for flagged keywords
      const moderationCheck = await checkContent(data.content);
      
      if (moderationCheck.shouldRedirect && moderationCheck.highestSeverity >= 9) {
        toast({
          title: "Content Blocked",
          description: "Your post contains prohibited content. Please review our community guidelines.",
          variant: "destructive",
        });
        window.location.href = '/anti-extremism';
        return;
      }

      const { data: insertData, error } = await supabase
        .from('messages')
        .insert({
          sender_id: user.id,
          content: data.content,
          message_type: 'community_post',
          location: data.location || null,
        })
        .select()
        .single();

      if (error) throw error;

      // If content was flagged but not blocked, create auto report
      if (moderationCheck.isFlagged && insertData) {
        await createAutoFlaggedReport(
          user.id,
          'post',
          insertData.id,
          data.content,
          moderationCheck.keywords
        );
        
        if (moderationCheck.highestSeverity >= 7) {
          toast({
            title: "Post Under Review",
            description: "Your post has been flagged for review by our moderation team.",
          });
        }
      }

      toast({
        title: "Post Created",
        description: "Your community post has been shared successfully!",
      });

      form.reset();
      onSuccess?.();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Share with Community</CardTitle>
        <CardDescription>
          Connect with Muslims around the world
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What's on your mind?</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Share news, ask questions, or connect with the community..."
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Chicago, IL" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-3">
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="flex-1"
              >
                {isSubmitting ? 'Posting...' : 'Share Post'}
              </Button>
              {onCancel && (
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onCancel}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
              )}
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};