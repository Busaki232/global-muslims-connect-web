import { MapPin, Search, Filter, Building } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HeroButton } from "@/components/ui/hero-button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

const GlobalLocations = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const handleBecomeLeader = () => {
    if (!user) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to apply for community leadership.",
      });
      navigate('/auth');
      return;
    }
    navigate('/leadership-application');
  };

  const globalCities = [
    {
      city: "Istanbul",
      country: "Turkey",
      mosques: 3500,
      population: "15M+",
      featured: true
    },
    {
      city: "Dubai",
      country: "UAE",
      mosques: 1800,
      population: "3.1M+",
      featured: true
    },
    {
      city: "Jakarta",
      country: "Indonesia",
      mosques: 4500,
      population: "9M+",
      featured: true
    },
    {
      city: "London",
      country: "UK",
      mosques: 423,
      population: "1.3M+",
      featured: false
    },
    {
      city: "Kuala Lumpur",
      country: "Malaysia",
      mosques: 350,
      population: "1.8M+",
      featured: false
    },
    {
      city: "Toronto",
      country: "Canada",
      mosques: 150,
      population: "400K+",
      featured: false
    }
  ];

  const featuredMosques = [
    {
      name: "Blue Mosque (Sultan Ahmed Mosque)",
      address: "Sultan Ahmet, Atmeydanı Cd. No:7, 34122 Fatih/İstanbul, Turkey",
      services: ["Daily Prayers", "Historical Site", "Tourist Attraction", "Islamic Architecture"],
      established: "1616"
    },
    {
      name: "Sheikh Zayed Grand Mosque",
      address: "Sheikh Rashid Bin Saeed Street, Abu Dhabi, UAE",
      services: ["Daily Prayers", "Guided Tours", "Cultural Center", "Islamic Education"],
      established: "2007"
    },
    {
      name: "Istiqlal Mosque",
      address: "Jl. Taman Wijaya Kusuma, Jakarta Pusat, Indonesia",
      services: ["Daily Prayers", "National Mosque", "Interfaith Dialogue", "Community Events"],
      established: "1978"
    },
    {
      name: "London Central Mosque",
      address: "146 Park Rd, London NW8 7RG, United Kingdom",
      services: ["Daily Prayers", "Islamic Cultural Centre", "Educational Programs", "Community Services"],
      established: "1977"
    },
    {
      name: "Masjid Negara (National Mosque of Malaysia)",
      address: "Jalan Perdana, 50480 Kuala Lumpur, Malaysia",
      services: ["Daily Prayers", "National Mosque", "Tours Available", "Islamic Heritage"],
      established: "1965"
    }
  ];

  return (
    <section id="global" className="py-16 bg-gradient-to-br from-background to-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Mosques Worldwide
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Connecting muslims worldwide
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Search Bar */}
          <div className="mb-8">
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
                    <Input 
                      placeholder="Search mosques, communities, or cities..."
                      className="pl-10 h-12 text-base"
                    />
                  </div>
                  <HeroButton size="lg" className="md:w-auto w-full">
                    <Filter className="mr-2" size={20} />
                    Filter Results
                  </HeroButton>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Midwest Cities */}
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-6">
                Major Global Cities
              </h3>
              <div className="space-y-4">
                {globalCities.map((city, index) => (
                  <Card key={index} className={`shadow-md hover:shadow-lg transition-all ${city.featured ? 'ring-2 ring-islamic-green/20' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
                            <MapPin className="text-white" size={20} />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground flex items-center gap-2">
                              {city.city}, {city.country}
                              {city.featured && <Badge className="bg-islamic-green text-white">Featured</Badge>}
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {city.population} Muslims
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-islamic-green">{city.mosques}</p>
                          <p className="text-xs text-muted-foreground">Mosques</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Featured Mosques */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-foreground">
                  Featured Islamic Centers
                </h3>
                <Link to="/mosques">
                  <HeroButton variant="outline" size="sm" className="flex items-center gap-2">
                    <Building size={16} />
                    View All Mosques
                  </HeroButton>
                </Link>
              </div>
              <div className="space-y-4">
                {featuredMosques.map((mosque, index) => (
                  <Card key={index} className="shadow-md hover:shadow-lg transition-all">
                    <CardContent className="p-4">
                      <div className="mb-3">
                        <h4 className="font-semibold text-foreground mb-1">
                          {mosque.name}
                        </h4>
                        <p className="text-sm text-muted-foreground flex items-center gap-1">
                          <MapPin size={12} />
                          {mosque.address}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {mosque.services.map((service, serviceIndex) => (
                          <Badge key={serviceIndex} variant="secondary" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Established {mosque.established}
                        </span>
                        <HeroButton 
                          variant="ghost" 
                          size="sm"
                          onClick={() => navigate('/mosques')}
                        >
                          View Details
                        </HeroButton>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-12 text-center">
            <Card className="bg-gradient-hero text-white shadow-islamic">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-4">
                  Expand Tariq Islam to Your City
                </h3>
                <p className="text-lg opacity-90 mb-6 max-w-2xl mx-auto">
                  Don't see your city listed? Help us grow the Tariq Islam global community 
                  network by becoming a community leader in your area.
                </p>
                <HeroButton 
                  size="lg"
                  onClick={handleBecomeLeader}
                  className="bg-white text-islamic-green hover:bg-white/90 touch-manipulation"
                >
                  Become a Community Leader
                </HeroButton>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GlobalLocations;