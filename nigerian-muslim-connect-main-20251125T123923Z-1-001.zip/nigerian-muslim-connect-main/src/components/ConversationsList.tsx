import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { logger } from '@/lib/logger';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { formatDistanceToNow } from 'date-fns';

interface Conversation {
  id: string;
  otherUserId: string;
  otherUserName: string;
  lastMessage?: string;
  lastMessageAt?: string;
  unreadCount: number;
}

interface ConversationsListProps {
  conversations: Conversation[];
  selectedConversation: Conversation | null;
  onSelectConversation: (conversation: Conversation) => void;
  onUpdateConversations: (conversations: Conversation[]) => void;
}

export const ConversationsList = ({
  conversations,
  selectedConversation,
  onSelectConversation,
  onUpdateConversations
}: ConversationsListProps) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    
    loadConversations();
    
    // Subscribe to new messages
    const channel = supabase
      .channel('private-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `recipient_id=eq.${user.id}`
        },
        () => {
          loadConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const loadConversations = async () => {
    if (!user) return;

    try {
      // Get all private messages where user is sender or recipient
      const { data: messages, error } = await supabase
        .from('messages')
        .select(`
          id,
          sender_id,
          recipient_id,
          content,
          created_at
        `)
        .not('recipient_id', 'is', null)
        .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Group messages by conversation and get user names
      const conversationMap = new Map<string, Conversation>();
      
      if (messages && messages.length > 0) {
        // Get unique user IDs to fetch their profiles
        const userIds = new Set<string>();
        messages.forEach(message => {
          if (message.sender_id !== user.id) userIds.add(message.sender_id);
          if (message.recipient_id && message.recipient_id !== user.id) userIds.add(message.recipient_id);
        });

        // Fetch user profiles using secure RPC function (phone numbers not exposed)
        const { data: allProfiles } = await supabase
          .rpc('get_all_public_profiles');
        
        // Filter to only the user IDs we need
        const profiles = allProfiles?.filter(p => userIds.has(p.user_id));

        const profileMap = new Map(profiles?.map(p => [p.user_id, p.full_name]) || []);

        messages.forEach((message) => {
          const otherUserId = message.sender_id === user.id ? message.recipient_id : message.sender_id;
          const otherUserName = profileMap.get(otherUserId!) || 'Unknown User';
          
          const conversationId = [user.id, otherUserId].sort().join('-');
          
          if (!conversationMap.has(conversationId)) {
            conversationMap.set(conversationId, {
              id: conversationId,
              otherUserId: otherUserId!,
              otherUserName,
              lastMessage: message.content,
              lastMessageAt: message.created_at,
              unreadCount: 0
            });
          }
        });
      }

      const conversationsList = Array.from(conversationMap.values());
      onUpdateConversations(conversationsList);
    } catch (error) {
      logger.error('Error loading conversations', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex-1 p-4">
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center space-x-3 animate-pulse">
              <div className="w-10 h-10 bg-muted rounded-full" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-muted rounded w-3/4" />
                <div className="h-3 bg-muted rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (conversations.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-muted-foreground">No conversations yet</p>
          <p className="text-sm text-muted-foreground mt-1">Start a new chat to connect with others</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-background">
      <div className="divide-y divide-border">
        {conversations.map((conversation) => (
          <div
            key={conversation.id}
            onClick={() => onSelectConversation(conversation)}
            className={`
              px-4 py-3 cursor-pointer transition-colors hover:bg-muted/50
              ${selectedConversation?.id === conversation.id ? 'bg-muted' : ''}
            `}
          >
            <div className="flex items-center gap-3">
              <Avatar className="w-12 h-12 flex-shrink-0">
                <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                  {conversation.otherUserName.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0 overflow-hidden">
                <div className="flex items-baseline justify-between gap-2 mb-1">
                  <p className="font-semibold text-foreground truncate">
                    {conversation.otherUserName}
                  </p>
                  {conversation.lastMessageAt && (
                    <span className="text-xs text-muted-foreground flex-shrink-0">
                      {formatDistanceToNow(new Date(conversation.lastMessageAt), { addSuffix: false })}
                    </span>
                  )}
                </div>
                
                <div className="flex items-center justify-between gap-2">
                  {conversation.lastMessage && (
                    <p className="text-sm text-muted-foreground truncate flex-1">
                      {conversation.lastMessage}
                    </p>
                  )}
                  {conversation.unreadCount > 0 && (
                    <Badge 
                      className="bg-primary text-primary-foreground flex-shrink-0 h-5 min-w-5 px-1.5 text-xs font-semibold"
                    >
                      {conversation.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};