import { useState, useRef, useEffect } from "react";
import { Group } from "@/hooks/useUserGroups";
import { useGroupMessages } from "@/hooks/useGroupMessages";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Send, Users, Settings, Loader2, Mic } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ScrollArea } from "./ui/scroll-area";
import { VoiceMessageRecorder } from "./VoiceMessageRecorder";
import { MessageStatus } from "./MessageStatus";
import { ImageUpload } from "./ImageUpload";
import { MessageAttachment } from "./MessageAttachment";
import { MessageReactions } from "./MessageReactions";
import { ShareQuranDialog, QuranVerseData } from "./ShareQuranDialog";
import { ShareHadithDialog, HadithData } from "./ShareHadithDialog";
import { QuranVerseCard } from "./QuranVerseCard";
import { HadithCard } from "./HadithCard";
import { JumuahPoll } from "./JumuahPoll";
import { VideoCallButton } from "./VideoCallButton";
import { VideoCallEmbed } from "./VideoCallEmbed";
import { useActiveCall } from "@/hooks/useActiveCall";

interface GroupMessage {
  id: string;
  sender_id: string;
  sender_name?: string;
  sender_location?: string;
  content: string;
  created_at: string;
  message_type: string;
  is_deleted: boolean;
  status?: "sending" | "sent" | "delivered" | "read";
  read_by?: Array<{ user_id: string; read_at: string }>;
  reactions?: Record<string, string[]>;
}

interface GroupChatWindowProps {
  group: Group;
  onOpenSettings: () => void;
}

const GroupChatWindow = ({ group, onOpenSettings }: GroupChatWindowProps) => {
  const { user } = useAuth();
  const { messages, loading, sendMessage } = useGroupMessages(group.id);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [messageAttachments, setMessageAttachments] = useState<Record<string, any[]>>({});
  const scrollRef = useRef<HTMLDivElement>(null);
  const { activeCallRoom, callType, endCall } = useActiveCall();

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
    if (messages.length > 0) {
      markGroupMessagesAsRead();
      loadAllAttachments();
    }
  }, [messages]);

  const loadAllAttachments = async () => {
    if (!messages.length) return;

    const messageIds = messages.map((m) => m.id);
    const { data, error } = await supabase.from("message_attachments").select("*").in("message_id", messageIds);

    if (error) {
      console.error("Error loading attachments:", error);
      return;
    }

    const attachmentsByMessage: Record<string, any[]> = {};
    data?.forEach((attachment) => {
      if (!attachmentsByMessage[attachment.message_id]) {
        attachmentsByMessage[attachment.message_id] = [];
      }
      attachmentsByMessage[attachment.message_id].push(attachment);
    });

    setMessageAttachments(attachmentsByMessage);
  };

  const handleSend = async () => {
    if (!newMessage.trim() || sending) return;

    setSending(true);
    const { success } = await sendMessage(newMessage.trim());
    if (success) {
      setNewMessage("");
      markGroupMessagesAsRead();
    }
    setSending(false);
  };

  const markGroupMessagesAsRead = async () => {
    if (!user) return;

    try {
      // Mark all messages in this group as read by current user
      const unreadMessages = (messages as GroupMessage[]).filter(
        (msg) => msg.sender_id !== user.id && (!msg.read_by || !msg.read_by.some((r) => r.user_id === user.id)),
      );

      for (const message of unreadMessages) {
        await supabase.rpc("mark_group_message_as_read", {
          _message_id: message.id,
        });
      }
    } catch (error) {
      console.error("Error marking messages as read:", error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);

  const handleVoiceMessage = async (blob: Blob, duration: number, mimeType: string) => {
    // Upload voice message to storage
    const fileName = `voice_${Date.now()}.webm`;
    const { data, error } = await supabase.storage.from("message-attachments").upload(`${user?.id}/${fileName}`, blob, {
      contentType: mimeType,
      upsert: false,
    });

    if (error) {
      toast.error("Failed to upload voice message");
      return;
    }

    const {
      data: { publicUrl },
    } = supabase.storage.from("message-attachments").getPublicUrl(data.path);

    await sendMessage(publicUrl, "voice");
    setShowVoiceRecorder(false);
  };

  const handleShareQuran = async (verse: QuranVerseData) => {
    const content = JSON.stringify(verse);
    await sendMessage(content, "quran");
  };

  const handleShareHadith = async (hadith: HadithData) => {
    const content = JSON.stringify(hadith);
    await sendMessage(content, "hadith");
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Active Call Overlay */}
      {activeCallRoom && (
        <VideoCallEmbed
          roomUrl={activeCallRoom}
          onLeave={endCall}
          userName={user?.user_metadata?.full_name || "User"}
          isAudioOnly={callType === "audio"}
        />
      )}

      {/* Header */}
      <div className="border-b bg-card p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={group.avatar_url} alt={group.name} />
              <AvatarFallback>
                <Users className="h-5 w-5" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-semibold">{group.name}</h2>
              {group.description && (
                <p className="text-sm text-muted-foreground truncate max-w-md">{group.description}</p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <VideoCallButton groupId={group.id} recipientName={group.name} variant="video" />
            <VideoCallButton groupId={group.id} recipientName={group.name} variant="audio" />
            <Button variant="ghost" size="icon" onClick={onOpenSettings}>
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-center text-muted-foreground">
            <div>
              <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No messages yet</p>
              <p className="text-sm">Start the conversation!</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {(messages as GroupMessage[]).map((message) => {
              const isOwn = message.sender_id === user?.id;

              return (
                <div key={message.id} className={`flex gap-3 ${isOwn ? "flex-row-reverse" : "flex-row"}`}>
                  {!isOwn && (
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      <AvatarFallback>{message.sender_name?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                  )}

                  <div className={`flex flex-col ${isOwn ? "items-end" : "items-start"} max-w-[70%]`}>
                    {!isOwn && <span className="text-xs font-medium mb-1">{message.sender_name}</span>}

                    <div className="space-y-2">
                      {message.message_type === "voice" ? (
                        <div
                          className={`rounded-lg px-4 py-2 ${
                            isOwn ? "bg-primary text-primary-foreground" : "bg-muted"
                          }`}
                        >
                          <audio src={message.content} controls className="max-w-xs" />
                        </div>
                      ) : message.message_type === "quran" ? (
                        <QuranVerseCard {...JSON.parse(message.content)} />
                      ) : message.message_type === "hadith" ? (
                        <HadithCard {...JSON.parse(message.content)} />
                      ) : message.message_type === "jumuah_poll" ? (
                        <JumuahPoll groupId={group.id} pollId={message.id} createdAt={message.created_at} />
                      ) : message.message_type === "image" ? null : message.content ? (
                        <div
                          className={`rounded-lg px-4 py-2 ${
                            isOwn ? "bg-primary text-primary-foreground" : "bg-muted"
                          }`}
                        >
                          <p className="whitespace-pre-wrap break-words">{message.content}</p>
                        </div>
                      ) : null}

                      {/* Render attachments */}
                      {messageAttachments[message.id]?.map((attachment) => (
                        <MessageAttachment key={attachment.id} attachment={attachment} />
                      ))}
                    </div>

                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}
                      </span>
                      {isOwn && message.status && (
                        <MessageStatus status={message.status} className="text-muted-foreground" />
                      )}
                    </div>

                    {/* Message Reactions */}
                    <div className="mt-2">
                      <MessageReactions messageId={message.id} reactions={message.reactions || {}} />
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={scrollRef} />
          </div>
        )}
      </ScrollArea>

      {/* Input */}
      <div className="border-t bg-card p-4">
        {showVoiceRecorder ? (
          <VoiceMessageRecorder onSend={handleVoiceMessage} onCancel={() => setShowVoiceRecorder(false)} />
        ) : (
          <div className="flex gap-2 items-end">
            <div className="flex gap-1">
              <ShareQuranDialog onShare={handleShareQuran} />
              <ShareHadithDialog onShare={handleShareHadith} />
            </div>

              <ImageUpload
                onImageSelect={() => {}}
                onImageRemove={() => {}}
                onUploadComplete={async (data) => {
                  if (!user) {
                    data.reset();
                    return;
                  }

                  try {
                    // Send image message with empty content
                    const { success } = await sendMessage("", "image");

                    if (!success) {
                      toast.error("Failed to send message");
                      data.reset();
                      return;
                    }

                    // Get the most recent message (the one we just sent)
                    const { data: messageData } = await supabase
                      .from("messages")
                      .select("id")
                      .eq("sender_id", user.id)
                      .eq("group_id", group.id)
                      .order("created_at", { ascending: false })
                      .limit(1)
                      .single();

                    if (!messageData) {
                      toast.error("Failed to create message");
                      data.reset();
                      return;
                    }

                    // Create attachment record
                    const { error: attachError } = await supabase.from("message_attachments").insert({
                      message_id: messageData.id,
                      uploaded_by: user.id,
                      file_url: data.imageUrl,
                      thumbnail_url: data.thumbnailUrl,
                      file_type: "image",
                      file_name: "image.jpg",
                      file_size: data.metadata.compressedSize,
                      mime_type: "image/jpeg",
                      metadata: data.metadata,
                      original_file_size: data.metadata.originalSize,
                      compression_ratio: data.metadata.compressionRatio,
                    });

                    if (attachError) {
                      toast.error("Failed to save attachment");
                      data.reset();
                      return;
                    }

                    loadAllAttachments();
                    data.reset();
                    toast.success("Image sent");
                  } catch (error) {
                    console.error("Error sending image:", error);
                    toast.error("Failed to send image");
                    data.reset();
                  }
                }}
                messageId={`temp-${Date.now()}`}
                userId={user?.id || ""}
              />

            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowVoiceRecorder(true)}
              className="h-[60px] w-[60px] flex-shrink-0"
            >
              <Mic className="h-5 w-5" />
            </Button>

            <Textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="min-h-[60px] max-h-32 resize-none"
              disabled={sending}
            />

            <Button
              onClick={handleSend}
              disabled={!newMessage.trim() || sending}
              size="icon"
              className="h-[60px] w-[60px] flex-shrink-0"
            >
              {sending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default GroupChatWindow;
