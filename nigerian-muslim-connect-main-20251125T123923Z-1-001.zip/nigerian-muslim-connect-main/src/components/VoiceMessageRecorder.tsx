import { useState, useEffect } from 'react';
import { Mic, X, Send } from 'lucide-react';
import { HeroButton } from './ui/hero-button';
import { AudioRecorder } from '@/utils/audioRecorder';
import { cn } from '@/lib/utils';

interface VoiceMessageRecorderProps {
  onSend: (audioBlob: Blob, duration: number, mimeType: string) => Promise<void>;
  onCancel: () => void;
}

export const VoiceMessageRecorder = ({ onSend, onCancel }: VoiceMessageRecorderProps) => {
  const [recorder] = useState(() => new AudioRecorder());
  const [duration, setDuration] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    startRecording();
    return () => {
      if (recorder.isRecording()) {
        recorder.cancelRecording();
      }
    };
  }, []);

  useEffect(() => {
    if (!isRecording) return;

    const interval = setInterval(() => {
      setDuration(recorder.getDuration());
      
      // Maximum 5 minutes
      if (recorder.getDuration() >= 300) {
        handleSend();
      }
    }, 100);

    return () => clearInterval(interval);
  }, [isRecording]);

  const startRecording = async () => {
    try {
      await recorder.startRecording();
      setIsRecording(true);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start recording');
      onCancel();
    }
  };

  const handleSend = async () => {
    try {
      const { blob: audioBlob, mimeType } = await recorder.stopRecording();
      const finalDuration = recorder.getDuration();
      
      // Validate blob size
      if (audioBlob.size < 1000) {
        setError('Recording failed - audio too short or empty. Please try again.');
        console.error('[VoiceRecorder] Invalid blob size:', audioBlob.size);
        return;
      }
      
      console.log('[VoiceRecorder] Sending voice message:', {
        size: audioBlob.size,
        duration: finalDuration,
        mimeType
      });
      
      setIsRecording(false);
      await onSend(audioBlob, finalDuration, mimeType);
    } catch (err) {
      console.error('[VoiceRecorder] Error:', err);
      setError('Failed to send voice message');
    }
  };

  const handleCancel = () => {
    recorder.cancelRecording();
    setIsRecording(false);
    onCancel();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="flex flex-col items-center gap-8 p-8">
        {error && (
          <p className="text-destructive text-sm">{error}</p>
        )}
        
        <div className="text-4xl font-mono font-bold text-primary">
          {formatTime(duration)}
        </div>

        <div className="relative">
          <div className={cn(
            "absolute inset-0 rounded-full bg-primary/20 animate-ping",
            !isRecording && "hidden"
          )} />
          <div className="relative w-24 h-24 rounded-full bg-primary flex items-center justify-center">
            <Mic className="w-12 h-12 text-primary-foreground" />
          </div>
        </div>

        <div className="flex gap-4">
          <HeroButton
            onClick={handleCancel}
            variant="outline"
            size="lg"
            className="gap-2"
          >
            <X className="w-5 h-5" />
            Cancel
          </HeroButton>
          
          <HeroButton
            onClick={handleSend}
            size="lg"
            className="gap-2"
            disabled={duration < 0.5}
          >
            <Send className="w-5 h-5" />
            Send
          </HeroButton>
        </div>

        <p className="text-sm text-muted-foreground">
          Maximum duration: 5:00
        </p>
      </div>
    </div>
  );
};
