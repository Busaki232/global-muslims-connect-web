import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { ImagePlus, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { compressImage, generateThumbnail, validateImageFile, uploadImage } from "@/utils/imageUpload";

interface ImageUploadProps {
  onImageSelect: (file: File, preview: string) => void;
  onImageRemove: () => void;
  onUploadComplete: (data: {
    imageUrl: string;
    thumbnailUrl: string;
    metadata: any;
    reset: () => void;
  }) => void;
  messageId: string;
  userId: string;
  disabled?: boolean;
}

export const ImageUpload = ({
  onImageSelect,
  onImageRemove,
  onUploadComplete,
  messageId,
  userId,
  disabled,
}: ImageUploadProps) => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!validateImageFile(file)) {
      toast.error("Invalid image file. Please select a JPEG, PNG, or WebP image under 10MB.");
      return;
    }

    const previewUrl = URL.createObjectURL(file);
    setSelectedImage(file);
    setPreview(previewUrl);
    onImageSelect(file, previewUrl);
  };

  const handleRemove = () => {
    if (preview) {
      URL.revokeObjectURL(preview);
    }
    setSelectedImage(null);
    setPreview("");
    onImageRemove();
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleUpload = async () => {
    if (!selectedImage) return;

    setUploading(true);
    try {
      // Compress image
      const compressedImage = await compressImage(selectedImage);
      
      // Generate thumbnail
      const thumbnail = await generateThumbnail(selectedImage);

      // Upload to Supabase
      const result = await uploadImage(
        compressedImage,
        thumbnail,
        messageId,
        userId,
        selectedImage
      );

      onUploadComplete({
        ...result,
        reset: handleRemove,
      });
      toast.success("Image uploaded successfully");
    } catch (error) {
      console.error("Image upload error:", error);
      toast.error("Failed to upload image");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/heic"
        onChange={handleFileSelect}
        className="hidden"
        disabled={disabled || uploading}
      />

      {!selectedImage ? (
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled || uploading}
          className="shrink-0"
        >
          <ImagePlus className="h-5 w-5" />
        </Button>
      ) : (
        <div className="flex items-center gap-2">
          <div className="relative">
            <img
              src={preview}
              alt="Preview"
              className="h-16 w-16 object-cover rounded border"
            />
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
              onClick={handleRemove}
              disabled={uploading}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <Button
            type="button"
            onClick={handleUpload}
            disabled={uploading}
            size="sm"
          >
            {uploading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Uploading...
              </>
            ) : (
              "Send Image"
            )}
          </Button>
        </div>
      )}
    </div>
  );
};
