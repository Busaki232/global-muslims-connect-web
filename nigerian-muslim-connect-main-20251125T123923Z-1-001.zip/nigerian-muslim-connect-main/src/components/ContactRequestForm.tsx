import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { SecurityUtils } from '@/lib/security';
import { Shield, AlertTriangle, Clock, MessageSquare } from 'lucide-react';

const contactRequestSchema = z.object({
  name: z.string().trim().min(1, 'Name is required').max(100, 'Name must be less than 100 characters'),
  email: z.string().trim().email('Please enter a valid email address').max(255, 'Email must be less than 255 characters'),
  message: z.string().trim().min(10, 'Message must be at least 10 characters').max(1000, 'Message must be less than 1000 characters'),
  reason: z.string().trim().min(10, 'Please provide a reason for contact').max(500, 'Reason must be less than 500 characters'),
});

type ContactRequestData = z.infer<typeof contactRequestSchema>;

interface UserReputation {
  reputation_score: number;
  total_requests: number;
  approved_requests: number;
  rejected_requests: number;
}

interface ContactRequestFormProps {
  advertisementId: string;
  businessName: string;
  onSuccess?: () => void;
  onCancel?: () => void;
  onMessagingRequested?: (contactRequestId: string) => void;
}

export const ContactRequestForm = ({ 
  advertisementId, 
  businessName, 
  onSuccess, 
  onCancel,
  onMessagingRequested
}: ContactRequestFormProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userReputation, setUserReputation] = useState<UserReputation | null>(null);
  const [riskScore, setRiskScore] = useState<number>(0);
  const [pendingRequestId, setPendingRequestId] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  const form = useForm<ContactRequestData>({
    resolver: zodResolver(contactRequestSchema),
    defaultValues: {
      name: '',
      email: '',
      message: '',
      reason: '',
    },
  });

  useEffect(() => {
    if (user) {
      fetchUserReputation();
      calculateRiskScore();
    }
  }, [user, advertisementId]);

  const fetchUserReputation = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_reputation')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') { // Not found error is ok
        return;
      }

      setUserReputation(data || {
        reputation_score: 50,
        total_requests: 0,
        approved_requests: 0,
        rejected_requests: 0
      });
    } catch (error) {
      // Silent fail - default reputation values used
    }
  };

  const calculateRiskScore = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase.rpc('calculate_risk_score', {
        _user_id: user.id,
        _advertisement_id: advertisementId
      });

      if (error) throw error;
      setRiskScore(data || 0);
    } catch (error) {
      // Silent fail - default risk score used
    }
  };

  const onSubmit = async (data: ContactRequestData) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to send a contact request.",
        variant: "destructive",
      });
      return;
    }

    // Validate input for security
    const sanitizedData = {
      name: SecurityUtils.sanitizeText(data.name),
      email: SecurityUtils.sanitizeText(data.email),
      message: SecurityUtils.sanitizeText(data.message),
      reason: SecurityUtils.sanitizeText(data.reason)
    };

    // Check for suspicious patterns
    const suspiciousInputs = [sanitizedData.name, sanitizedData.email, sanitizedData.message, sanitizedData.reason];
    if (suspiciousInputs.some(input => SecurityUtils.containsSuspiciousPatterns(input))) {
      toast({
        title: "Invalid Input",
        description: "Please remove any suspicious content and try again.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Use secure RPC function that blocks direct table access
      // This ensures PII is protected and proper validation occurs
      const { data: result, error } = await supabase
        .rpc('submit_contact_request_secure', {
          _advertisement_id: advertisementId,
          _requester_name: sanitizedData.name,
          _requester_email: sanitizedData.email,
          _message: `${sanitizedData.reason}\n\nMessage: ${sanitizedData.message}`
        });

      if (error) throw error;

      // Extract ID from secure response
      const requestId = (result as any)?.id;
      if (requestId) {
        setPendingRequestId(requestId);
      }

      // Log security event (already done in RPC function but logged here for monitoring)
      SecurityUtils.logSecurityEvent('contact_request_submitted', {
        advertisementId,
        riskScore,
        requiresVerification: riskScore > 50
      });

      toast({
        title: "Request Sent Successfully",
        description: "Your contact request has been sent securely. The business owner will review it and may contact you through our secure messaging system.",
      });
      form.reset();
      onSuccess?.();
    } catch (error: any) {
      // Error handled with user-friendly messages below
      
      if (error.message?.includes('rate limit')) {
        toast({
          title: "Rate Limit Exceeded",
          description: "You've sent too many requests recently. Please wait before sending another.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to send contact request. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };


  const openMessaging = () => {
    if (pendingRequestId && onMessagingRequested) {
      onMessagingRequested(pendingRequestId);
    }
  };

  const getReputationBadgeVariant = (score: number) => {
    if (score >= 70) return 'default';
    if (score >= 40) return 'secondary';
    return 'destructive';
  };

  const getRiskBadgeVariant = (score: number) => {
    if (score < 30) return 'default';
    if (score < 60) return 'secondary';
    return 'destructive';
  };


  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Contact {businessName}</CardTitle>
        <CardDescription>
          Send a secure message to request contact information from this business.
        </CardDescription>
        
        {/* User reputation and risk indicators */}
        {userReputation && (
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant={getReputationBadgeVariant(userReputation.reputation_score)}>
              <Shield className="w-3 h-3 mr-1" />
              Reputation: {userReputation.reputation_score}/100
            </Badge>
            {riskScore > 0 && (
              <Badge variant={getRiskBadgeVariant(riskScore)}>
                <AlertTriangle className="w-3 h-3 mr-1" />
                Risk: {riskScore < 30 ? 'Low' : riskScore < 60 ? 'Medium' : 'High'}
              </Badge>
            )}
          </div>
        )}
        
        {riskScore > 60 && (
          <Alert className="mt-2">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Your request may require additional verification due to security policies.
            </AlertDescription>
          </Alert>
        )}
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your full name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="Enter your email address" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reason for Contact</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Why do you want to contact this business? (e.g., interested in services, have questions, want to collaborate)"
                      className="min-h-[80px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any additional information you'd like to share..."
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Alert>
              <MessageSquare className="h-4 w-4" />
              <AlertDescription>
                All communications will be handled through our secure messaging system to protect both parties' privacy.
              </AlertDescription>
            </Alert>

            <div className="flex gap-3">
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="flex-1"
              >
                {isSubmitting ? 'Sending...' : 'Send Secure Request'}
              </Button>
              {onCancel && (
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onCancel}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
              )}
            </div>
            
            {pendingRequestId && (
              <Button 
                variant="outline" 
                onClick={openMessaging}
                className="w-full"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Open Secure Messaging
              </Button>
            )}
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};