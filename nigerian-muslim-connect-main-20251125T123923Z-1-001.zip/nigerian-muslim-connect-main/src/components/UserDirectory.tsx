import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { logger } from '@/lib/logger';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Search, MessageCircle } from 'lucide-react';

interface UserProfile {
  user_id: string;
  full_name: string;
  location?: string;
}

interface UserDirectoryProps {
  onSelectUser: (userId: string, userName: string) => void;
  onClose: () => void;
}

export const UserDirectory = ({ onSelectUser, onClose }: UserDirectoryProps) => {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, [user]);

  const loadUsers = async () => {
    if (!user) return;

    try {
      // Use secure RPC function to get public profiles
      const { data, error } = await supabase
        .rpc('get_all_public_profiles');

      if (error) throw error;

      // Filter out current user and sort
      const filteredUsers = (data || [])
        .filter(profile => profile.user_id !== user.id)
        .sort((a, b) => (a.full_name || '').localeCompare(b.full_name || ''));

      setUsers(filteredUsers);
    } catch (error) {
      logger.error('Error loading users', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = users.filter(userProfile =>
    userProfile.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    userProfile.location?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleUserSelect = (userProfile: UserProfile) => {
    onSelectUser(userProfile.user_id, userProfile.full_name);
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          placeholder="Search users..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Users List */}
      <div className="flex-1 overflow-y-auto max-h-[60vh]">
        {loading ? (
          <div className="space-y-3 p-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center space-x-3 animate-pulse">
                <div className="w-10 h-10 bg-muted rounded-full" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded w-3/4" />
                  <div className="h-3 bg-muted rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">
              {searchTerm ? 'No users found' : 'No users available'}
            </p>
          </div>
        ) : (
          <div className="space-y-1 p-2">
            {filteredUsers.map((userProfile) => (
              <div
                key={userProfile.user_id}
                onClick={() => handleUserSelect(userProfile)}
                className="flex items-center space-x-3 p-3 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
              >
                <Avatar>
                  <AvatarFallback>
                    {userProfile.full_name?.charAt(0).toUpperCase() || '?'}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">
                    {userProfile.full_name || 'Unknown User'}
                  </p>
                  {userProfile.location && (
                    <p className="text-sm text-muted-foreground truncate">
                      {userProfile.location}
                    </p>
                  )}
                </div>
                
                <Button variant="ghost" size="sm">
                  <MessageCircle className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};