import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { Upload } from 'lucide-react';

const adSchema = z.object({
  title: z.string().trim().min(3, 'Title must be at least 3 characters').max(100, 'Title must be less than 100 characters'),
  description: z.string().trim().min(10, 'Description must be at least 10 characters').max(1000, 'Description must be less than 1000 characters'),
  category_id: z.string().uuid('Please select a category'),
  location: z.string().trim().max(100, 'Location must be less than 100 characters').optional(),
  contact_phone: z.string().trim().max(20, 'Phone must be less than 20 characters').optional(),
  contact_email: z.string().trim().email('Invalid email address').max(255, 'Email must be less than 255 characters').optional(),
  website: z.string().trim()
    .max(255, 'Website must be less than 255 characters')
    .refine((val) => {
      if (!val || val === '') return true; // Empty is OK
      
      // If it looks like a URL attempt (has dots or slashes), validate it
      if (val.includes('.') || val.includes('/')) {
        try {
          new URL(val.startsWith('http') ? val : `https://${val}`);
          return true;
        } catch {
          return false;
        }
      }
      
      // Otherwise allow any text (like "Coming soon")
      return true;
    }, { message: 'Please enter a valid URL or descriptive text' })
    .optional()
    .or(z.literal('')),
});

type AdFormData = z.infer<typeof adSchema>;

interface Category {
  id: string;
  name: string;
  description: string;
}

interface AdSubmissionFormProps {
  onSuccess?: () => void;
  mode?: 'create' | 'edit';
  advertisementId?: string;
  initialData?: Partial<AdFormData>;
  existingImageUrl?: string | null;
}

export const AdSubmissionForm: React.FC<AdSubmissionFormProps> = ({ 
  onSuccess, 
  mode = 'create',
  advertisementId,
  initialData,
  existingImageUrl 
}) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [keepExistingImage, setKeepExistingImage] = useState(!!existingImageUrl);
  const { toast } = useToast();
  const { user } = useAuth();

  const form = useForm<AdFormData>({
    resolver: zodResolver(adSchema),
    defaultValues: initialData || {
      title: '',
      description: '',
      category_id: '',
      location: '',
      contact_phone: '',
      contact_email: '',
      website: '',
    },
  });

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    const { data, error } = await supabase
      .from('categories')
      .select('id, name, description')
      .order('name');
    
    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to load categories',
        variant: 'destructive',
      });
      return;
    }
    
    setCategories(data || []);
  };

  const uploadImage = async (file: File): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${user?.id}/${Date.now()}.${fileExt}`;
    
    const { error: uploadError } = await supabase.storage
      .from('advertisements')
      .upload(fileName, file);

    if (uploadError) {
      toast({
        title: 'Error',
        description: 'Failed to upload image',
        variant: 'destructive',
      });
      return null;
    }

    const { data } = supabase.storage
      .from('advertisements')
      .getPublicUrl(fileName);

    return data.publicUrl;
  };

  const onSubmit = async (data: AdFormData) => {
    if (!user) {
      toast({
        title: 'Error',
        description: 'You must be logged in to submit an ad',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      let imageUrl = existingImageUrl;

      // Upload new image if provided
      if (imageFile) {
        imageUrl = await uploadImage(imageFile);
        if (!imageUrl) {
          setIsSubmitting(false);
          return;
        }
      } else if (!keepExistingImage) {
        imageUrl = null;
      }

      const adData = {
        title: data.title,
        description: data.description,
        category_id: data.category_id,
        user_id: user.id,
        image_url: imageUrl,
        website: data.website || null,
        location: data.location || null,
        contact_phone: data.contact_phone || null,
        contact_email: data.contact_email || null,
      };

      if (mode === 'edit' && advertisementId) {
        // Update existing advertisement
        const { error } = await supabase
          .from('advertisements')
          .update(adData)
          .eq('id', advertisementId);

        if (error) throw error;

        toast({
          title: 'Success',
          description: 'Your advertisement has been updated',
        });
      } else {
        // Insert new advertisement
        const { error } = await supabase
          .from('advertisements')
          .insert(adData);

        if (error) throw error;

        toast({
          title: 'Success',
          description: 'Your advertisement has been submitted for review',
        });
      }

      form.reset();
      setImageFile(null);
      onSuccess?.();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'An unexpected error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'Error',
          description: 'Image must be less than 5MB',
          variant: 'destructive',
        });
        return;
      }
      setImageFile(file);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>
          {mode === 'edit' ? 'Edit Your Advertisement' : 'Submit Your Business'}
        </CardTitle>
        <CardDescription>
          {mode === 'edit' 
            ? 'Update your business information' 
            : 'Share your halal business or service with the community'
          }
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Business Name *</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your business name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description *</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your business, services, or products..."
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category *</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location</FormLabel>
                  <FormControl>
                    <Input placeholder="City, State" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="contact_phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input placeholder="(555) 123-4567" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="contact_email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="business@example.com" type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="website"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Website (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="https://www.yourbusiness.com (or leave blank)" {...field} />
                  </FormControl>
                  <p className="text-sm text-muted-foreground">
                    Enter your website URL or leave blank if you don't have one yet
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <label className="text-sm font-medium">Business Image</label>
              {existingImageUrl && keepExistingImage && !imageFile && (
                <div className="space-y-2">
                  <img
                    src={existingImageUrl}
                    alt="Current"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setKeepExistingImage(false)}
                  >
                    Remove Image
                  </Button>
                </div>
              )}
              <div className="flex items-center gap-4">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="image-upload"
                />
                <label
                  htmlFor="image-upload"
                  className="flex items-center gap-2 px-4 py-2 border border-input bg-background hover:bg-accent hover:text-accent-foreground rounded-md cursor-pointer"
                >
                  <Upload className="h-4 w-4" />
                  {existingImageUrl && keepExistingImage ? 'Change Image' : 'Choose Image'}
                </label>
                {imageFile && (
                  <span className="text-sm text-muted-foreground">
                    {imageFile.name}
                  </span>
                )}
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting 
                ? (mode === 'edit' ? 'Updating...' : 'Submitting...') 
                : (mode === 'edit' ? 'Update Advertisement' : 'Submit Advertisement')
              }
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};