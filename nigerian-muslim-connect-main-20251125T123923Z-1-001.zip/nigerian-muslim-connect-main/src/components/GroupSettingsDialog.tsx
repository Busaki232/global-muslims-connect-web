import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Group } from '@/hooks/useUserGroups';
import { useGroupMembers } from '@/hooks/useGroupMembers';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { UserPlus, UserMinus, Shield, Users as UsersIcon, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

interface GroupSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  group: Group;
}

const GroupSettingsDialog = ({ open, onOpenChange, group }: GroupSettingsDialogProps) => {
  const { user } = useAuth();
  const { members, loading, removeMember, updateMemberRole } = useGroupMembers(group.id);
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [adding, setAdding] = useState(false);

  const isAdmin = members.find(m => m.user_id === user?.id)?.role === 'admin';

  const handleAddMember = async () => {
    if (!newMemberEmail.trim()) {
      toast.error('Please enter an email');
      return;
    }

    setAdding(true);
    try {
      // Find user by email
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('user_id', newMemberEmail)  // This would need to be updated to search by email
        .single();

      if (profileError || !profile) {
        toast.error('User not found');
        return;
      }

      // Add member
      const { error } = await supabase
        .from('group_members')
        .insert({
          group_id: group.id,
          user_id: profile.user_id,
          role: 'member'
        });

      if (error) throw error;

      toast.success('Member added successfully');
      setNewMemberEmail('');
    } catch (error: any) {
      toast.error(error.message || 'Failed to add member');
    } finally {
      setAdding(false);
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    const result = await removeMember(memberId);
    if (result.success) {
      toast.success('Member removed');
    }
  };

  const handleRoleChange = async (memberId: string, newRole: 'admin' | 'moderator' | 'member') => {
    const result = await updateMemberRole(memberId, newRole);
    if (result.success) {
      toast.success('Role updated');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Group Settings</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="members" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="members">
              <UsersIcon className="h-4 w-4 mr-2" />
              Members
            </TabsTrigger>
            <TabsTrigger value="info">Group Info</TabsTrigger>
          </TabsList>

          <TabsContent value="members" className="space-y-4">
            {isAdmin && (
              <div className="space-y-2 p-4 border rounded-lg bg-muted/50">
                <Label>Add Member</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter user ID or email"
                    value={newMemberEmail}
                    onChange={(e) => setNewMemberEmail(e.target.value)}
                  />
                  <Button onClick={handleAddMember} disabled={adding}>
                    {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            )}

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {loading ? (
                <div className="flex justify-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                members.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>
                          {member.full_name?.charAt(0) || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{member.full_name || 'Unknown User'}</p>
                        {member.location && (
                          <p className="text-sm text-muted-foreground">{member.location}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant={member.role === 'admin' ? 'default' : 'secondary'}>
                        {member.role === 'admin' && <Shield className="h-3 w-3 mr-1" />}
                        {member.role}
                      </Badge>
                      
                      {isAdmin && member.user_id !== user?.id && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveMember(member.id)}
                        >
                          <UserMinus className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="info" className="space-y-4">
            <div className="space-y-2">
              <Label>Group Name</Label>
              <Input value={group.name} disabled />
            </div>

            {group.description && (
              <div className="space-y-2">
                <Label>Description</Label>
                <p className="text-sm text-muted-foreground p-3 border rounded-lg">
                  {group.description}
                </p>
              </div>
            )}

            <div className="space-y-2">
              <Label>Group Type</Label>
              <p className="text-sm capitalize p-3 border rounded-lg">
                {group.group_type.replace('_', ' ')}
              </p>
            </div>

            <div className="space-y-2">
              <Label>Created</Label>
              <p className="text-sm text-muted-foreground p-3 border rounded-lg">
                {new Date(group.created_at).toLocaleDateString()}
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default GroupSettingsDialog;
