import { useAuth } from "@/hooks/useAuth";
import { HeroButton } from "@/components/ui/hero-button";
import { CheckCircle2, UserPlus, ArrowRight, Sparkles, Globe, Users, Heart } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CallToActionSection = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleCTA = () => {
    if (user) {
      navigate("/dashboard");
    } else {
      navigate("/auth");
    }
  };

  const benefits = [
    { icon: Globe, text: "Connect with Muslims worldwide" },
    { icon: Users, text: "Join local and global community events" },
    { icon: Heart, text: "Share your faith journey and inspire others" },
    { icon: Sparkles, text: "Access exclusive Islamic resources and tools" },
  ];

  return (
    <section className="relative py-16 md:py-24 bg-gradient-to-br from-islamic-green via-islamic-green/95 to-islamic-gold/20 overflow-hidden">
      {/* Islamic Pattern Background */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left Column - Copy & Benefits */}
            <div className="text-white space-y-6">
              {user ? (
                <>
                  <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20">
                    <Sparkles className="w-4 h-4 text-islamic-gold" />
                    <span className="text-sm font-medium">Welcome Back!</span>
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold leading-tight">
                    Explore Your Community
                  </h2>
                  <p className="text-lg text-white/90">
                    Dive into the full Tariq Islam experience. Connect with your brothers and sisters, track your prayers, and strengthen your faith journey.
                  </p>
                </>
              ) : (
                <>
                  <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20">
                    <Users className="w-4 h-4 text-islamic-gold" />
                    <span className="text-sm font-medium">Join 3,247+ Muslims Worldwide</span>
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold leading-tight">
                    Start Your Spiritual Journey Today
                  </h2>
                  <p className="text-lg text-white/90">
                    Join the global Tariq Islam community and stay connected to your faith, wherever you are.
                  </p>
                </>
              )}

              {/* Benefits List */}
              <ul className="space-y-3 pt-4">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-islamic-gold/20 flex items-center justify-center mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-islamic-gold" />
                    </div>
                    <span className="text-white/90">{benefit.text}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Right Column - CTA Card */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 shadow-2xl">
              <div className="text-center space-y-6">
                <div className="w-16 h-16 mx-auto bg-gradient-gold rounded-full flex items-center justify-center shadow-lg">
                  {user ? (
                    <ArrowRight className="w-8 h-8 text-white" />
                  ) : (
                    <UserPlus className="w-8 h-8 text-white" />
                  )}
                </div>

                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-white">
                    {user ? "Continue Your Journey" : "Create Your Free Account"}
                  </h3>
                  <p className="text-white/80">
                    {user 
                      ? "Access your dashboard and community features"
                      : "No credit card required. Join in seconds."
                    }
                  </p>
                </div>

                <HeroButton
                  variant="secondary"
                  size="xl"
                  onClick={handleCTA}
                  className="w-full group"
                >
                  {user ? (
                    <>
                      Go to Dashboard
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </>
                  ) : (
                    <>
                      Get Started Free
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </HeroButton>

                {!user && (
                  <p className="text-xs text-white/60">
                    Already have an account?{" "}
                    <button 
                      onClick={() => navigate("/auth")}
                      className="text-islamic-gold hover:underline font-medium"
                    >
                      Sign in
                    </button>
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToActionSection;
