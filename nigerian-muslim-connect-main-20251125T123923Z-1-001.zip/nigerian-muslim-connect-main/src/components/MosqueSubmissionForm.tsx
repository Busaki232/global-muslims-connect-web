import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Building, Clock, Phone, Globe, Mail, MapPin, User, Languages } from "lucide-react";
import { logger } from "@/lib/logger";

const mosqueSubmissionSchema = z.object({
  mosque_name: z.string().trim().nonempty("Mosque name is required").max(100),
  address: z.string().trim().nonempty("Address is required").max(200),
  city: z.string().trim().nonempty("City is required").max(50),
  state: z.string().trim().nonempty("State is required").max(20),
  zip_code: z.string().trim().optional(),
  phone: z.string().trim().optional(),
  email: z.string().trim().email("Invalid email format").optional().or(z.literal("")),
  website: z.string().trim().optional(),
  imam_name: z.string().trim().optional(),
  description: z.string().trim().max(1000, "Description must be less than 1000 characters").optional(),
  // Prayer times
  fajr: z.string().trim().optional(),
  dhuhr: z.string().trim().optional(),
  asr: z.string().trim().optional(),
  maghrib: z.string().trim().optional(),
  isha: z.string().trim().optional(),
  jummah: z.string().trim().optional()
});

type MosqueSubmissionFormData = z.infer<typeof mosqueSubmissionSchema>;

const MosqueSubmissionForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const { user } = useAuth();
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<MosqueSubmissionFormData>({
    resolver: zodResolver(mosqueSubmissionSchema)
  });

  const languageOptions = [
    "English", "Arabic", "Urdu", "French", "Turkish", "Malay", "Indonesian", 
    "Bengali", "Persian", "Hausa", "Yoruba", "Swahili", "Somali", "Pashto", "Kurdish"
  ];
  const serviceOptions = [
    "Daily Prayers",
    "Jummah Prayers", 
    "Islamic Education",
    "Youth Programs",
    "Women's Programs",
    "Community Outreach",
    "Community Events",
    "Islamic School",
    "Marriage Services",
    "Funeral Services",
    "Counseling",
    "Food Bank",
    "Interfaith Dialogue"
  ];

  const handleLanguageChange = (language: string, checked: boolean) => {
    if (checked) {
      setSelectedLanguages(prev => [...prev, language]);
    } else {
      setSelectedLanguages(prev => prev.filter(l => l !== language));
    }
  };

  const handleServiceChange = (service: string, checked: boolean) => {
    if (checked) {
      setSelectedServices(prev => [...prev, service]);
    } else {
      setSelectedServices(prev => prev.filter(s => s !== service));
    }
  };

  const onSubmit = async (data: MosqueSubmissionFormData) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to submit a mosque.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Prepare prayer times object
      const prayerTimes = {
        fajr: data.fajr || null,
        dhuhr: data.dhuhr || null,
        asr: data.asr || null,
        maghrib: data.maghrib || null,
        isha: data.isha || null,
        jummah: data.jummah || null
      };

      const { error } = await supabase
        .from("mosque_submissions")
        .insert({
          user_id: user.id,
          mosque_name: data.mosque_name,
          address: data.address,
          city: data.city,
          state: data.state,
          zip_code: data.zip_code || null,
          phone: data.phone || null,
          email: data.email || null,
          website: data.website || null,
          imam_name: data.imam_name || null,
          description: data.description || null,
          languages: selectedLanguages,
          services: selectedServices,
          prayer_times: prayerTimes
        });

      if (error) throw error;

      toast({
        title: "Submission Successful!",
        description: "Your mosque submission has been received and is under review.",
        variant: "default"
      });

      reset();
      setSelectedLanguages([]);
      setSelectedServices([]);

    } catch (error: any) {
      logger.error('Error submitting mosque', error);
      toast({
        title: "Submission Failed",
        description: error.message || "An error occurred while submitting your mosque.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-islamic-green/10 rounded-full flex items-center justify-center mb-4">
          <Building className="w-6 h-6 text-islamic-green" />
        </div>
        <CardTitle className="text-2xl text-foreground">Submit a Mosque</CardTitle>
        <p className="text-muted-foreground">
          Help us build a comprehensive directory of Islamic centers across the Midwest
        </p>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Basic Information</h3>
            
            <div>
              <Label htmlFor="mosque_name">Mosque/Islamic Center Name *</Label>
              <Input 
                id="mosque_name"
                {...register("mosque_name")}
                placeholder="e.g., Islamic Center of Chicago"
                className={errors.mosque_name ? "border-destructive" : ""}
              />
              {errors.mosque_name && (
                <p className="text-sm text-destructive mt-1">{errors.mosque_name.message}</p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="address">Street Address *</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input 
                    id="address"
                    {...register("address")}
                    placeholder="123 Main Street"
                    className={`pl-10 ${errors.address ? "border-destructive" : ""}`}
                  />
                </div>
                {errors.address && (
                  <p className="text-sm text-destructive mt-1">{errors.address.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="city">City *</Label>
                <Input 
                  id="city"
                  {...register("city")}
                  placeholder="Chicago"
                  className={errors.city ? "border-destructive" : ""}
                />
                {errors.city && (
                  <p className="text-sm text-destructive mt-1">{errors.city.message}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="state">State *</Label>
                <Input 
                  id="state"
                  {...register("state")}
                  placeholder="IL"
                  className={errors.state ? "border-destructive" : ""}
                />
                {errors.state && (
                  <p className="text-sm text-destructive mt-1">{errors.state.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="zip_code">ZIP Code</Label>
                <Input 
                  id="zip_code"
                  {...register("zip_code")}
                  placeholder="60610"
                />
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Contact Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input 
                    id="phone"
                    {...register("phone")}
                    placeholder="(312) 555-0100"
                    className="pl-10"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input 
                    id="email"
                    {...register("email")}
                    placeholder="info@masjid.org"
                    type="email"
                    className={`pl-10 ${errors.email ? "border-destructive" : ""}`}
                  />
                </div>
                {errors.email && (
                  <p className="text-sm text-destructive mt-1">{errors.email.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="website">Website</Label>
              <div className="relative">
                <Globe className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input 
                  id="website"
                  {...register("website")}
                  placeholder="www.masjid.org"
                  className="pl-10"
                />
              </div>
            </div>
          </div>

          {/* Religious Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Religious Information</h3>
            
            <div>
              <Label htmlFor="imam_name">Imam/Religious Leader</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input 
                  id="imam_name"
                  {...register("imam_name")}
                  placeholder="Sheikh Abdullah Hassan"
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Label className="flex items-center gap-2 mb-3">
                <Languages className="w-4 h-4" />
                Languages Spoken
              </Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {languageOptions.map((language) => (
                  <div key={language} className="flex items-center space-x-2">
                    <Checkbox
                      id={`language-${language}`}
                      checked={selectedLanguages.includes(language)}
                      onCheckedChange={(checked) => handleLanguageChange(language, checked as boolean)}
                    />
                    <Label htmlFor={`language-${language}`} className="text-sm">
                      {language}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Services Offered</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                {serviceOptions.map((service) => (
                  <div key={service} className="flex items-center space-x-2">
                    <Checkbox
                      id={`service-${service}`}
                      checked={selectedServices.includes(service)}
                      onCheckedChange={(checked) => handleServiceChange(service, checked as boolean)}
                    />
                    <Label htmlFor={`service-${service}`} className="text-sm">
                      {service}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Prayer Times */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Prayer Times
            </h3>
            <p className="text-sm text-muted-foreground">
              Please provide prayer times in 12-hour format (e.g., 5:30 AM)
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="fajr">Fajr</Label>
                <Input 
                  id="fajr"
                  {...register("fajr")}
                  placeholder="5:30 AM"
                />
              </div>
              <div>
                <Label htmlFor="dhuhr">Dhuhr</Label>
                <Input 
                  id="dhuhr"
                  {...register("dhuhr")}
                  placeholder="12:45 PM"
                />
              </div>
              <div>
                <Label htmlFor="asr">Asr</Label>
                <Input 
                  id="asr"
                  {...register("asr")}
                  placeholder="3:30 PM"
                />
              </div>
              <div>
                <Label htmlFor="maghrib">Maghrib</Label>
                <Input 
                  id="maghrib"
                  {...register("maghrib")}
                  placeholder="6:15 PM"
                />
              </div>
              <div>
                <Label htmlFor="isha">Isha</Label>
                <Input 
                  id="isha"
                  {...register("isha")}
                  placeholder="8:00 PM"
                />
              </div>
              <div>
                <Label htmlFor="jummah">Jummah</Label>
                <Input 
                  id="jummah"
                  {...register("jummah")}
                  placeholder="1:00 PM"
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...register("description")}
              placeholder="Tell us about your mosque, community programs, special features..."
              rows={4}
              className={errors.description ? "border-destructive" : ""}
            />
            {errors.description && (
              <p className="text-sm text-destructive mt-1">{errors.description.message}</p>
            )}
          </div>

          <Button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full"
            size="lg"
          >
            {isSubmitting ? "Submitting..." : "Submit Mosque"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default MosqueSubmissionForm;