import { HeroButton } from "@/components/ui/hero-button";
import { MapPin, CheckCircle2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import islamicPatternBg from "@/assets/islamic-pattern-bg.jpg";

const HeroSection = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { coords, requestLocation, loading } = useGeolocation();
  const { toast } = useToast();
  const [locationRequesting, setLocationRequesting] = useState(false);

  const handleFindMosquesNearby = async () => {
    if (locationRequesting || loading) return;

    setLocationRequesting(true);
    try {
      await requestLocation();

      // Small delay to ensure coords are updated
      setTimeout(() => {
        if (coords) {
          toast({
            title: "Location obtained",
            description: "Showing mosques near your location",
          });
          navigate(`/mosques?lat=${coords.latitude}&lng=${coords.longitude}`);
        } else {
          // Fallback to general mosques page
          toast({
            title: "Location unavailable",
            description: "Showing all mosques in your area",
          });
          navigate("/mosques");
        }
        setLocationRequesting(false);
      }, 500);
    } catch (error) {
      toast({
        title: "Location unavailable",
        description: "Showing all mosques in your area",
      });
      navigate("/mosques");
      setLocationRequesting(false);
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={islamicPatternBg}
          alt="Islamic geometric pattern background for global Muslim community"
          className="w-full h-full object-cover"
          loading="eager"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-hero/90">
          <div className="absolute inset-0 bg-black/50"></div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Arabic Greeting */}
          <div className="mb-6">
            <p className="text-2xl md:text-3xl text-white/90 font-light mb-2" dir="rtl" lang="ar">
              السلام عليكم ورحمة الله وبركاته
            </p>
            <p className="text-lg text-white/80">May the peace, mercy, and blessings of Allah be upon you</p>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            <span className="block">Stay connected to your faith and community worldwide</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed">
            Find prayer times, locate mosques, and connect with Muslims around the globe.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            {user ? (
              <>
                <Link to="/chat">
                  <HeroButton size="xl" className="w-full sm:w-auto" aria-label="Join the community chat">
                    Join Chat Room
                  </HeroButton>
                </Link>
                <HeroButton
                  variant="outline"
                  size="xl"
                  className="w-full sm:w-auto touch-manipulation"
                  aria-label="Find nearby mosques"
                  onClick={handleFindMosquesNearby}
                  disabled={locationRequesting || loading}
                >
                  <MapPin className="mr-2" aria-hidden="true" />
                  {locationRequesting || loading ? "Getting Location..." : "Find Mosques Nearby"}
                </HeroButton>
              </>
            ) : (
              <>
                <Link to="/auth">
                  <HeroButton size="xl" className="w-full sm:w-auto" aria-label="Sign up to join the community">
                    Join Now - It's Free
                  </HeroButton>
                </Link>
                <HeroButton
                  variant="outline"
                  size="xl"
                  className="w-full sm:w-auto touch-manipulation"
                  aria-label="Find nearby mosques"
                  onClick={handleFindMosquesNearby}
                  disabled={locationRequesting || loading}
                >
                  <MapPin className="mr-2" aria-hidden="true" />
                  {locationRequesting || loading ? "Getting Location..." : "Find Mosques Nearby"}
                </HeroButton>
              </>
            )}
          </div>

          {/* Why Join Section */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 max-w-2xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6 text-center">Why Join Tariq Islam?</h2>

            {/* Benefits List */}
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-islamic-gold flex items-center justify-center mt-0.5">
                  <CheckCircle2 className="w-4 h-4 text-white" />
                </div>
                <span className="text-white text-lg">Meet Muslims worldwide in real time</span>
              </li>

              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-islamic-gold flex items-center justify-center mt-0.5">
                  <CheckCircle2 className="w-4 h-4 text-white" />
                </div>
                <span className="text-white text-lg">Find nearby mosques and events</span>
              </li>

              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-islamic-gold flex items-center justify-center mt-0.5">
                  <CheckCircle2 className="w-4 h-4 text-white" />
                </div>
                <span className="text-white text-lg">Access Quran, prayer times, and more</span>
              </li>
            </ul>

            {/* Privacy Statement */}
            <div className="mt-8 pt-6 border-t border-white/20">
              <p className="text-white/80 text-center text-sm">
                Your privacy and data are protected. We never share your information.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-white/20 to-transparent"></div>
    </section>
  );
};

export default HeroSection;
