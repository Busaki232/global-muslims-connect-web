import { useState, useEffect } from "react";
import { Users, MessageCircle, Calendar, MapPin, Heart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HeroButton } from "@/components/ui/hero-button";
import { Badge } from "@/components/ui/badge";
import { CreatePostModal } from "./CreatePostModal";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { logger } from "@/lib/logger";
import communityMosque from "@/assets/community-mosque.jpg";

interface CommunityPost {
  id: string;
  author: string;
  time: string;
  content: string;
  likes: number;
  comments: number;
  location?: string;
  sender_id: string;
}

const CommunitySection = () => {
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const fetchCommunityPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`
          id,
          content,
          created_at,
          location,
          sender_id,
          profiles!inner(full_name)
        `)
        .eq('message_type', 'community_post')
        .eq('is_deleted', false)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;

      const posts: CommunityPost[] = data.map((post: any) => ({
        id: post.id,
        author: post.profiles?.full_name || 'Anonymous User',
        time: formatTimeAgo(new Date(post.created_at)),
        content: post.content,
        likes: Math.floor(Math.random() * 50), // Placeholder - would need likes table
        comments: Math.floor(Math.random() * 20), // Placeholder - would need comments table
        location: post.location || undefined,
        sender_id: post.sender_id,
      }));

      setCommunityPosts(posts);
    } catch (error) {
      logger.error('Error fetching posts', error);
      // Fallback to mock data if fetch fails
      setCommunityPosts([
        {
          id: '1',
          author: "Aisha Olumide",
          time: "2 hours ago",
          content: "Assalamu alaikum! Looking for a study group for Quran memorization in Chicago area. Anyone interested?",
          likes: 12,
          comments: 5,
          location: "Chicago, IL",
          sender_id: "mock1"
        },
        {
          id: '2',
          author: "Ibrahim Adamu", 
          time: "5 hours ago",
          content: "Ramadan preparation workshop this weekend at Detroit Islamic Center. Free for all!",
          likes: 28,
          comments: 8,
          location: "Detroit, MI",
          sender_id: "mock2"
        },
        {
          id: '3',
          author: "Fatima Hassan",
          time: "1 day ago", 
          content: "Islamic Cultural Night - Saturday 7PM. Traditional food, lectures, and community bonding",
          likes: 45,
          comments: 15,
          location: "Minneapolis, MN",
          sender_id: "mock3"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} ${days === 1 ? 'day' : 'days'} ago`;
    }
  };

  const handleCreatePost = () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to create a post.",
        variant: "destructive",
      });
      return;
    }
    setIsCreatePostOpen(true);
  };

  const handlePostCreated = () => {
    fetchCommunityPosts(); // Refresh posts after creating
  };

  useEffect(() => {
    fetchCommunityPosts();
  }, []);

  const upcomingEvents = [
    {
      title: "Friday Prayer & Lecture",
      date: "Tomorrow",
      time: "1:00 PM",
      location: "Islamic Society of Greater Chicago",
      attendees: 124
    },
    {
      title: "Muslim Youth Meet",
      date: "This Saturday",
      time: "3:00 PM", 
      location: "Detroit Community Center",
      attendees: 67
    },
    {
      title: "Islamic Financial Planning",
      date: "Next Sunday",
      time: "2:00 PM",
      location: "Milwaukee Islamic Center",
      attendees: 89
    }
  ];

  return (
    <section id="community-section" className="py-16 bg-gradient-to-br from-secondary/30 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Community Hub
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Connect, share, and grow together with Muslims worldwide
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {/* Community Stats */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="bg-gradient-primary text-primary-foreground shadow-islamic border-0">
              <CardContent className="p-6 text-center">
                <Users size={40} className="mx-auto mb-4 opacity-90" />
                <h3 className="text-2xl font-bold mb-2">3,247</h3>
                <p className="opacity-90">Muslims Connected Globally</p>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="text-islamic-green" size={20} />
                  Upcoming Events
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {upcomingEvents.map((event, index) => (
                  <div key={index} className="border-l-4 border-islamic-green pl-4 py-2">
                    <h4 className="font-semibold text-sm">{event.title}</h4>
                    <p className="text-xs text-muted-foreground mb-1">
                      {event.date} at {event.time}
                    </p>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin size={12} />
                        {event.location}
                      </p>
                      <Badge variant="secondary" className="text-xs">
                        {event.attendees} going
                      </Badge>
                    </div>
                  </div>
                ))}
                <HeroButton 
                  size="sm" 
                  className="w-full mt-4"
                  onClick={() => navigate('/events')}
                >
                  View All Events
                </HeroButton>
              </CardContent>
            </Card>
          </div>

          {/* Community Feed */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <MessageCircle className="text-islamic-green" size={24} />
                    Community Feed
                  </CardTitle>
                  <HeroButton variant="outline" size="sm" onClick={handleCreatePost}>
                    Create Post
                  </HeroButton>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {loading ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Loading community posts...
                  </div>
                ) : communityPosts.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No posts yet. Be the first to share something!
                  </div>
                ) : (
                  communityPosts.map((post) => (
                  <div key={post.id} className="border-b border-border/50 pb-6 last:border-b-0 last:pb-0">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center text-white font-semibold">
                        {post.author.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold text-sm">{post.author}</h4>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground">{post.time}</span>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <MapPin size={10} />
                            {post.location}
                          </span>
                        </div>
                        <p className="text-sm text-foreground mb-3 leading-relaxed">
                          {post.content}
                        </p>
                        <div className="flex items-center gap-4">
                          <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-islamic-green transition-colors">
                            <Heart size={14} />
                            {post.likes}
                          </button>
                          <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-islamic-green transition-colors">
                            <MessageCircle size={14} />
                            {post.comments}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  ))
                )}
                
                {!loading && communityPosts.length > 0 && (
                  <div className="pt-4">
                    <HeroButton variant="ghost" className="w-full">
                      Load More Posts
                    </HeroButton>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Community Image Section */}
        <div className="mt-16 text-center">
          <div className="relative max-w-4xl mx-auto rounded-2xl overflow-hidden shadow-xl">
            <img 
              src={communityMosque} 
              alt="Global Islamic community gathering at mosque" 
              className="w-full h-64 md:h-80 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
              <div className="p-8 text-white">
                <h3 className="text-2xl md:text-3xl font-bold mb-2">
                  Building Bridges, Strengthening Faith Globally
                </h3>
                <p className="text-lg opacity-90">
                  Join thousands of Muslims creating lasting connections worldwide
                </p>
              </div>
            </div>
          </div>
        </div>

        <CreatePostModal
          isOpen={isCreatePostOpen}
          onClose={() => setIsCreatePostOpen(false)}
          onPostCreated={handlePostCreated}
        />
      </div>
    </section>
  );
};

export default CommunitySection;