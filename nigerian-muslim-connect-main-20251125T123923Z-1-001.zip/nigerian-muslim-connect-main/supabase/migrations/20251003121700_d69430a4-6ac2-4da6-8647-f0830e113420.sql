-- Update Qaato African Restaurant address
UPDATE advertisements 
SET location = '7118 N Clark St, Chicago, IL 60626',
    updated_at = now()
WHERE id = '752553c9-b6c7-42f0-bb7a-13bac71e521a';