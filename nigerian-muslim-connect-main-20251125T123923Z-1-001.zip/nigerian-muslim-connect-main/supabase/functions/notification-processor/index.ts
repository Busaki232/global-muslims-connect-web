import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    console.log("Processing notification queue...");

    // Fetch pending notifications that are ready to be sent
    const { data: pendingNotifications, error: fetchError } = await supabase
      .from("notification_queue")
      .select("*")
      .eq("is_sent", false)
      .lte("scheduled_at", new Date().toISOString())
      .order("user_id")
      .order("notification_type")
      .order("created_at");

    if (fetchError) {
      console.error("Error fetching notifications:", fetchError);
      throw fetchError;
    }

    if (!pendingNotifications || pendingNotifications.length === 0) {
      console.log("No pending notifications to process");
      return new Response(JSON.stringify({ message: "No notifications to process" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    console.log(`Found ${pendingNotifications.length} pending notifications`);

    // Group notifications by user and type
    const notificationsByUser = pendingNotifications.reduce((acc: any, notif: any) => {
      if (!acc[notif.user_id]) {
        acc[notif.user_id] = {};
      }
      if (!acc[notif.user_id][notif.notification_type]) {
        acc[notif.user_id][notif.notification_type] = [];
      }
      acc[notif.user_id][notif.notification_type].push(notif);
      return acc;
    }, {});

    const processedIds: string[] = [];

    // Process each user's notifications
    for (const [userId, typeGroups] of Object.entries(notificationsByUser)) {
      // Check user's notification preferences
      const { data: preferences } = await supabase
        .from("user_notification_preferences")
        .select("*")
        .eq("user_id", userId)
        .single();

      if (!preferences || !preferences.notifications_enabled) {
        continue;
      }

      // Process each notification type
      for (const [type, notifications] of Object.entries(typeGroups as any)) {
        const notifList = notifications as any[];
        
        // Check if bundling is enabled
        if (preferences.enable_summary_notifications && notifList.length > 1) {
          // Create bundled notification
          const bundleId = crypto.randomUUID();
          const titles = notifList.map((n: any) => n.title);
          const uniqueChats = new Set(notifList.map((n: any) => n.metadata?.conversationId || n.metadata?.groupId));
          
          let summaryTitle = "";
          let summaryBody = "";
          
          if (type === "dm") {
            summaryTitle = `${notifList.length} new messages`;
            summaryBody = uniqueChats.size > 1 
              ? `from ${uniqueChats.size} conversations`
              : titles[0];
          } else if (type === "group" || type === "mention") {
            summaryTitle = type === "mention" 
              ? `${notifList.length} new mentions` 
              : `${notifList.length} new group messages`;
            summaryBody = uniqueChats.size > 1 
              ? `in ${uniqueChats.size} groups`
              : titles[0];
          } else if (type === "event") {
            summaryTitle = `${notifList.length} event reminders`;
            summaryBody = titles.join(", ");
          }

          // Mark notifications as bundled
          const notifIds = notifList.map((n: any) => n.id);
          await supabase
            .from("notification_queue")
            .update({ 
              is_bundled: true, 
              bundle_id: bundleId,
              is_sent: true,
              sent_at: new Date().toISOString()
            })
            .in("id", notifIds);

          processedIds.push(...notifIds);
          
          console.log(`Bundled ${notifList.length} ${type} notifications for user ${userId}`);
        } else {
          // Mark individual notifications as sent
          const notifIds = notifList.map((n: any) => n.id);
          await supabase
            .from("notification_queue")
            .update({ 
              is_sent: true,
              sent_at: new Date().toISOString()
            })
            .in("id", notifIds);

          processedIds.push(...notifIds);
          
          console.log(`Sent ${notifList.length} individual ${type} notifications for user ${userId}`);
        }
      }
    }

    console.log(`Processed ${processedIds.length} notifications`);

    return new Response(
      JSON.stringify({ 
        message: "Notifications processed successfully",
        processed: processedIds.length 
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error in notification processor:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
