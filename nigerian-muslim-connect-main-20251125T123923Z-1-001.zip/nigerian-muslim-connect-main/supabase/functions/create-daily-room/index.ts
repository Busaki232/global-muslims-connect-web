import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const DAILY_API_KEY = Deno.env.get('DAILY_API_KEY');

    if (!DAILY_API_KEY) {
      throw new Error('DAILY_API_KEY not configured');
    }

    // Parse request body to get call type
    const { callType, conversationId, groupId } = await req.json();
    console.log('[create-daily-room] Request:', { callType, conversationId, groupId });

    // Generate predictable room name based on conversation or group
    let roomName: string;
    if (conversationId) {
      roomName = `gmc-conv-${conversationId}`;
    } else if (groupId) {
      roomName = `gmc-group-${groupId}`;
    } else {
      throw new Error('Either conversationId or groupId must be provided');
    }
    console.log('[create-daily-room] Creating room:', roomName);

    // Create room via Daily.co API
    const response = await fetch('https://api.daily.co/v1/rooms', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${DAILY_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: roomName,
        privacy: 'public',
        properties: {
          enable_screenshare: true,
          enable_chat: false,
          start_video_off: callType === 'audio',
          exp: Math.floor(Date.now() / 1000) + 3600 // 1 hour expiration
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[create-daily-room] Daily.co API error:', response.status, errorText);
      throw new Error(`Daily.co API error: ${response.status} ${errorText}`);
    }

    const room = await response.json();
    console.log('[create-daily-room] Room created successfully:', room.name);

    // Construct the full room URL
    const roomUrl = `https://global-muslims-connec.daily.co/${room.name}`;
    console.log('[create-daily-room] Room URL:', roomUrl);

    // Return room URL and details
    return new Response(
      JSON.stringify({
        roomUrl: roomUrl,
        roomName: room.name,
        callType: callType
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("[create-daily-room] Error:", error);
    return new Response(
      JSON.stringify({
        error: error.message || "Failed to create call room",
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
