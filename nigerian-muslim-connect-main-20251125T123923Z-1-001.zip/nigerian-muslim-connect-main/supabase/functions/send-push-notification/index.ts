import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// VAPID keys for Web Push - In production, generate your own keys
// Use: npx web-push generate-vapid-keys
const VAPID_PUBLIC_KEY = "BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDpEdsNeFSe1-6F0ErSYywTUMNsYLdVjzJsZ7FKSthZg";
const VAPID_PRIVATE_KEY = Deno.env.get('VAPID_PRIVATE_KEY') || "your-vapid-private-key";

interface PushSubscription {
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
}

interface NotificationPayload {
  userId?: string;
  userIds?: string[];
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  data?: any;
  actions?: Array<{ action: string; title: string; icon?: string }>;
  priority?: number;
}

async function sendWebPush(subscription: PushSubscription, payload: any) {
  try {
    // Build the push message
    const message = JSON.stringify(payload);
    
    // Note: In a real implementation, you would use the web-push library
    // For now, we'll use a basic fetch to the push service
    // This is a simplified version - in production, use proper JWT signing
    
    const response = await fetch(subscription.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'TTL': '86400', // 24 hours
      },
      body: message,
    });

    if (!response.ok) {
      throw new Error(`Push failed: ${response.status} ${response.statusText}`);
    }

    return { success: true };
  } catch (error) {
    console.error('Error sending push notification:', error);
    return { success: false, error: error.message };
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    const { userId, userIds, title, body, icon, badge, data, actions, priority = 1 } = 
      await req.json() as NotificationPayload;

    if (!userId && !userIds) {
      throw new Error('Either userId or userIds must be provided');
    }

    if (!title) {
      throw new Error('Title is required');
    }

    // Get target user IDs
    const targetUserIds = userIds || [userId];

    // Fetch push subscriptions for the user(s)
    const { data: subscriptions, error: fetchError } = await supabaseClient
      .from('push_subscriptions')
      .select('*')
      .in('user_id', targetUserIds)
      .eq('is_active', true);

    if (fetchError) {
      throw new Error(`Failed to fetch subscriptions: ${fetchError.message}`);
    }

    if (!subscriptions || subscriptions.length === 0) {
      console.log('No active push subscriptions found for users:', targetUserIds);
      return new Response(
        JSON.stringify({ 
          message: 'No active push subscriptions found',
          sent: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Prepare notification payload
    const notificationPayload = {
      title,
      body,
      icon: icon || '/favicon.ico',
      badge: badge || '/favicon.ico',
      data: data || {},
      actions: actions || [],
    };

    // Send push notifications to all subscriptions
    const sendPromises = subscriptions.map(async (sub) => {
      const subscription: PushSubscription = {
        endpoint: sub.endpoint,
        keys: {
          p256dh: sub.p256dh,
          auth: sub.auth,
        },
      };

      const result = await sendWebPush(subscription, notificationPayload);
      
      if (!result.success) {
        // Mark subscription as inactive if push failed
        await supabaseClient
          .from('push_subscriptions')
          .update({ is_active: false })
          .eq('id', sub.id);
        
        console.log(`Deactivated subscription ${sub.id} due to push failure`);
      } else {
        // Update last_used_at
        await supabaseClient
          .from('push_subscriptions')
          .update({ last_used_at: new Date().toISOString() })
          .eq('id', sub.id);
      }

      return result;
    });

    const results = await Promise.all(sendPromises);
    const successCount = results.filter(r => r.success).length;
    const failureCount = results.filter(r => !r.success).length;

    console.log(`Push notifications sent: ${successCount} succeeded, ${failureCount} failed`);

    return new Response(
      JSON.stringify({ 
        message: 'Push notifications processed',
        sent: successCount,
        failed: failureCount,
        total: results.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in send-push-notification function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
