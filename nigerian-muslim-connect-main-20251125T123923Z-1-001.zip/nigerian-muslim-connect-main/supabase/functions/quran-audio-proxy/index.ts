import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// Allowed origins for CORS
const allowedOrigins = [
  'https://170fff7e-50b5-4875-86af-17548009ba00.lovableproject.com',
  'http://localhost:8080',
  'http://127.0.0.1:8080',
];

const getCorsHeaders = (origin: string | null) => ({
  'Access-Control-Allow-Origin': origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0],
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, range',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges',
});

// Rate limiting: Track requests by IP address
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_WINDOW = 60 * 60 * 1000; // 1 hour in milliseconds
const MAX_REQUESTS_PER_HOUR = 50; // 50 audio requests per IP per hour (lower due to bandwidth)

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const existing = rateLimitMap.get(ip);
  
  if (!existing || now > existing.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return true;
  }
  
  if (existing.count >= MAX_REQUESTS_PER_HOUR) {
    return false;
  }
  
  existing.count++;
  return true;
}

function cleanupRateLimitMap() {
  const now = Date.now();
  for (const [ip, data] of rateLimitMap.entries()) {
    if (now > data.resetTime) {
      rateLimitMap.delete(ip);
    }
  }
}

serve(async (req) => {
  const origin = req.headers.get('origin');
  const corsHeaders = getCorsHeaders(origin);
  
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Rate limiting: Get client IP
    const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
                     req.headers.get('x-real-ip') || 
                     'unknown';
    
    // Check rate limit
    if (!checkRateLimit(clientIp)) {
      console.warn(`Rate limit exceeded for IP: ${clientIp}`);
      return new Response(
        JSON.stringify({ 
          error: 'Rate limit exceeded. Maximum 50 audio requests per hour.' 
        }),
        { 
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }
    
    // Periodic cleanup (every 50th request approximately)
    if (Math.random() < 0.02) {
      cleanupRateLimitMap();
    }

    const url = new URL(req.url);
    const surahNumber = url.searchParams.get('surah');
    const reciterSubdirectory = url.searchParams.get('reciter');

    if (!surahNumber || !reciterSubdirectory) {
      return new Response(
        JSON.stringify({ error: 'Missing surah number or reciter subdirectory' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log(`Proxying audio: Surah ${surahNumber}, Reciter ${reciterSubdirectory}`);

    // Try multiple audio sources with fallback
    const audioSources = [
      // Primary: everyayah.com
      `https://everyayah.com/data/${reciterSubdirectory}/${surahNumber}.mp3`,
      // Fallback 1: mp3quran.net (Abdul Rahman Al-Sudais)
      `https://server8.mp3quran.net/afs/${surahNumber}.mp3`,
      // Fallback 2: quran.com CDN
      `https://verses.quran.com/AbdulBaset/Mujawwad/mp3/${surahNumber}.mp3`,
    ];

    let audioResponse: Response | null = null;
    let successfulUrl = '';

    for (const audioUrl of audioSources) {
      try {
        console.log(`Attempting to fetch from: ${audioUrl}`);
        
        const response = await fetch(audioUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; QuranPlayer/1.0)',
          },
        });

        if (response.ok) {
          audioResponse = response;
          successfulUrl = audioUrl;
          console.log(`Successfully fetched from: ${audioUrl}`);
          break;
        } else {
          console.log(`Failed to fetch from ${audioUrl}: ${response.status}`);
        }
      } catch (error) {
        console.error(`Error fetching from ${audioUrl}:`, error);
      }
    }

    if (!audioResponse) {
      return new Response(
        JSON.stringify({ error: 'Unable to fetch audio from any source' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Forward the audio response with CORS headers
    const audioBuffer = await audioResponse.arrayBuffer();
    
    return new Response(audioBuffer, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'audio/mpeg',
        'Content-Length': audioBuffer.byteLength.toString(),
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'public, max-age=86400', // Cache for 24 hours
        'X-Audio-Source': successfulUrl,
      },
    });

  } catch (error) {
    console.error('Error in quran-audio-proxy:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
